// ==UserScript==
// @name         【全新升级】百度文库原文档免费下载，文档内容自由复制，移除广告；豆丁网文档下载；解除大部分网站操作限制；全网VIP视频免费在线看[支持电视剧免跳出选集]
// @namespace    crack_vip_document_dissertation
// @version      3.0.6
// @description  【1】可下载百度文库免费和需下载券的原文档[全新升级]，文档内容自由复制，移除网页广告(注：下载调用第三方网站数据，该网站首次下载需关注公众号)；【2】豆丁文库文档免费下载；【3】解除大部分常用网站的操作限制；【4】全网VIP视频免费看[电视剧免跳出选集，当前适配：爱奇艺、腾讯视频、优酷、芒果、搜狐视频]，支持腾讯视频、爱奇艺、优酷、芒果tv等(注：VIP解析作者会经常更新维护，为更好的服务大家，因此要求大家关注公众号[关注一次即可])
// @author       crack_vip_document_dissertation_broom
// @icon 		 data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADICAYAAACtWK6eAAAgAElEQVR4Xu1de5xUxZX+zu15gCJoHj6YHhM3GnWmR7OrGzer+a35JZuNkelGE8SIEvGRqAGVhygqiKiIgG8xmsQXiEZdlelB3WTzMLtmN0bNRqcHTTSrcboHcU0UhMwwM33P/up2N46Emb63qu6ju2v+nK5Tdeo79d26t+o8CObPIGAQGBEBMtgYBAwCIyNgCGJWh0FgFAQMQczyMAgYgpg1YBCQQ8DsIHK4GakaQcAQpEYMbaYph4AhiBxuRqpGEDAEqRFDm2nKIWAIIoebkaoRBAxBasTQZppyCBiCyOFmpGoEAUOQGjG0maYcAoYgcrhplWpu706xZX8TjI84HRP+TLZ1X09na4fWgUxnnhEwBPEMmT6BicnM0THgYRAm7qpXZs6xXTclt/7Q/9Y3qunJCwKGIF7Q0tg2nuy6gIhuKtclg/vAWJBNt91crq35XT8ChiD6MR21x+bjNyQQy98DoiM9Dc38PPKxGT1PtGQ8yZnGSggYgijB50H4uFcb4w3brwTzXCKq8yC5oykzD4Ho+uxA4xV46qDtMn0YGW8IGIJ4w0uqdXxy17Fk4y4Q/Y1UBzsLMf8vWzgzu67taS39mU5GRMAQxMfFMbH9dx+zrIEbCHSaH8MweI1tN8zp7Tz4HT/6N32KA0Xz5wsCTanMdAJuIOCjvgxQ7JSBPzEwJ9eRWO3nOLXatyGIZsvv0/7KAfU0dBcRvqC561G7Y8bPB7nuzE2dh7we5LjVPpYhiC4LT+FY0/YN8y3wIhDG6OrWSz/OkTBoSbahdQUeobwXWdN21wgYgmhYGfFU91EE+wcAJVS7YzBI+c2XMwzrrGxH67Oq+tS6vCGIwgr4WPKVPcZgaCkI5xFgKXSlXZQBG+BV/Vx/2TvpQ97XPkCNdGgIImnoeGrDVwu7BvaT7AIf7BbCDLxTN+T8h5hVj1I2FnaTlidl9axlOUMQj9b/2Ikb9hszZN9GhBM9iobanIFH+2PWrHcea9kYqiIVNrghiGuDMTUnM+cAtAyE8a7FdmpY2ie8As9MYjtR/DrhzTbjklw6cafTmfkri4BXO5XtsBobTGx/6RCL6B4i+geV+TEziNQgd167VJQQL3PMv7KZZ/R2HvaKYldVL66KdXUDdNyrjU312y+3iC8GqL66JsuDNtN1uUZchUcSA9U1N32zMQQZAcuJkzLHxCy+T8V/SnyEiz9yDrh0v9EQmG1nO1E5FmbGq7aNM3rXJ57Rt6yqpydDkJ1suf/xL+3FdXQ9QDOqx8zlZ8LMd1t5nvfmE4e9W7517bQwBBlm63iq+xTAvpFAe8sugcJ3hiVe9NU/FtwqUfwwUf3GYfDbZNOFPZ2JB90OXe3tDEEATJyU2T8Ww/cBfLnaDe5yfj/O53F27/rEmy7bV22zGicIW82pzBxmXElEu8laWY97iOzou5IrfJ+onJgx8zaCdUVPuuVGgGyd2lVSXzVLkKZJmcMphnsJ+IyawXQcvKppMKK0BtUY+C3ncXpufeJFn7SMdLc1R5B9vvzi7g1jY1cx+HwCxSJtnYgox+A8Md3MjRMuzz7S3BcRtQJRo6YIMjHZ9c8W4W4CxeXRLRzX6vC5ldfBm+SOA2bFi0oG/mgzn92bbvt3bxpUbuuaIMg+J7y2d4PddwtAUyvXVBHSnPHDgdiYCzY9fuDbEdLKF1WqniDxVOYsAq8AaE9ZBAsntgVfqGr4k/UH+9Dcmd9lxkXZzra7qgGTkeZQtQSJJ7sPJOK7AXy+mg0Ygbn9JzOdkU23vhYBXbSrUH0EmZJpiG+nBQReAEKjCmIaDoFUhg9EVngJk4itUnGiZIgcXdf05PqX4YUjBwNRPKBBqoogIvQVzGuIcJAsfoXXKXGzYYGq5JWqHBYlV3rhLqbCEwAvM2hGNYX6VgVB9vrSHybsvlvfcgBnk4rnXrmVZH4viwAzmMB39qF+fjWE+lY8QZqS3VMs8C0g7FvWeqM0EH5M4vFZ8YCogFDyOXagUH7B3Mg2ZmU7E48qqhSqeMWuh/ik3zXBGriTiI4PFUEz+KgIMPMTsBu+nV1/cK4SoapAgrAVT2ZmgehqAsbJg178ztAepyGvUWQlFTcTZrwPpsuynS23VdpZeUURRJQO4Dp7jar/lJZ7gMiu5ggrVoElHCqCIPEpPWOxffNigOfIlg6I8LKpLNWUdxMeAtPK7FDj4koo4RB5gojSAWASXrefkF1Jzo6hfoQpO3z1yXEhgFjpSLhCSjhEliBO6QAauJGITq2+FWZmVEIg6iUcIkmQpvbM6WRhpVLpgB1hqIpPOrOWR0SgcDJOyuHFzHiHCXOjWMIhUgQJq3SA4UA0EIhiCYdoEOSI5+ubJjZeZBEtVCodULzsi4a5a1ULta/4qJVwCJ0g+01++Yg6zq8BcKjSklKzi9LQRng4AuKVS9H50TlT4a481c3YuO7QF8LENzSCFEsHXAvCuVErHRCmQczYHyBQKuEw2Gcv2PTjw7eFgU0oBNFbOiAM2MyYbhEoZJdU83FjcBaIfTuMEg6BEsQpHZDPryLQCW4BNu0MAh8cCQdfwiEggjA1p7rPBUO8UimUDiilShBqV0f4a+0sf10FgYIt4eA7QUTpgBjRGhAdWTuLwczUbwSCKuHgH0GOe7WxuWFgIWDPVykdIE5uCxnMzV81IaCnIBAGbIYo4XC1XyUcfFl3OkoHFBaDObutJlLsai46LOxnCQftBGlKZWZbwA0qhi3sGuLkw3xnqOBYMbI6nB8B2DZm5zoTN+mct1aCNKe6Pw/wfygp6NyG+1FwRkkrI+w7AuoJt4WKtm19LtfZ8itd6molSDzV9RKB2qSUMx8bUrBVm5ByMBvzb3rSbUfowkUbQZqTXUeC6DmvijnJEkoXSdq08aqFaR8pBBQLAg0NccvGJ9pe1jEnbUsynuy6gIg8vf9Fr66GDkhNH7oQkPY9ZT6zJ90msmoq/2kkSPdyIr7IjUaO+wHXTmI2N5iYNqMhIL5PRGk7dygxsCDbkVjmrvXorVwOWX6opmRmiUVYWL6laWEQ8B2BmT0diVU6RtFGkHiyexoR3+9FqUKyNssc53oBrYbaCsci4TrvtZScbdMXc52tP9MBlTaC7J3s2qeR6C0ppXTcFkkNbIQiiwDLlZsQObiy6YS0v9/OeGgjiOi4OdV1B0DflgFdtYSxzJhGJqoIyD8xbaZLc+nWa3XNTCtBnCAoGnqegE/rUtD0YxBwiwAznss2tn4Oj1DerUy5dloJIgabmOpqtkCPEHBUucFH/F36fE96RCMYNgKKNhfevbAbvq47B7B2ghRwZqspueFii3gxgIawsTfjVzECjO1MWJztaF3uRz13nwhSMMi+qUxLHeMBIhwuYyLnkl3UkzW+WTLwRVymcLch/tzeb+w8IWa8yLHYSbnHD/29X5P1lSCO0sdyXXxC90IwX2ry6vplxtrql5mHAOvq7JaWa/A0Dfk5e/8JUtQ+nuw6DMDDRHSwzISccw3F91SZcY2MfgTkz6hEEkf+HYCTsum2l/Rr9tc9BkYQZ2inwCauAmGeSfUThHmrZwwG52HTiuwYXOFX9OCu0AqWIKXdZFLms7CwlggHypiwlErGeX+V6cDIBIZAKbO+Stg0M17L29bUjetbfhOY4sWBQltfnzz29TFDE7ZeB6ZZpjRg0GavjPEKBUFxc2zL7gveePqA/jC0Do0gpclOTHX9owX8kEDNMgCU4kmc3ST02cjMoPpkSp+Kit4Rb+TB03o72v4rTIQisaT2+fKLuzeMta6XdVMJE0Aztg8IMH2XG8fPzT7S3OdD7566jARBShrH21/+J6L8AyBM9DSLHY1FnIlwcjOJ5eTwU5EqLSVb/suQ0cscOyXbeegvVDTRKRspgoiJCX+usRi6FYRv6pyo6SvqCPA9fVx/wTvpQ96PkqaRI8iO3STZ/RXAXk1EH5cCzNlMqHh3ItWDESqHgI50PcybGNbp2XTrv5UbLozfI0sQAUb8X7o/QmPs2wGaGgY4Zkx/EWDGg1ut3c97b90B7/k7knzvkSZIaVoTU5l2CxCVbj8iNdVSSVbneEWqByNUQqB0Da5wHc7An23g9N6ORGfUga2Y5VKoeju4mgjHRR1Uo98oCDDSea4/s7fz4HcqAaeKIUgJzKbJXadZjFsA2lMGYOdsHpZw7JIRr1mZAlql8hMSMDC/y7BmZdOtayWkQxOpOIIIpEQhnrH5/GqAvhQacmZgDwjwTwassdM2PX7g2x6EItG0IglSQi6ezJwN4Hoi7CGDpnKaS5lBK0xG6TacsYWZ52Q72+6qsGnvUFcLQUTKH4BPJBKA0E+z6VZP6X9UwGs67tW4Vb/9hyAcrdKPkdWLAANP80DjabmnDsrq7Xnk3ppSmekW8AUGxpGNx3o6Ew+qjq1EkP0mbfi7mJVPE1HThxRhfj1v0/Te9YlnVBV0J88Ub98wE2QvI6Ld3Mns1MpsJzsAUQm7YeZtRDS/pyNxu5QdJISK9WhWg+iA4eKi+CcTtefWJX4r0a0jIk2Q5sldn2Kb/mfU1xvGDT3pxFxZ5bzK7ffVDZ+I1dsPKSWM8Dqoaf8BsYBn84PW1I1PtvwxKFiak5nrQZgz0ngiT9Yg1x2+qfOQ12V0kiZIPJm5lQgzyw0adASYSBgRT2bmEkgEZjWW02/Xv9dWWu3ClYbSxYZwRb+sJ916kx+JE3ZlIy8Rqsx0czbdeqHMWpAnSCrzBgGfcDsoMy3OpluvdNtetV3TCS9/mvL5h2UTRqiOXzvy/AIIU3vWtf0hqDnHk12LiegKt+OJgKtsOnGQ2/bD20kTpDmV6QWwn5dBg8hC8SF9juW65vHdl4B4kWwhUYXnqhdoQmmrOLcB2+Yrc50iizoJF17f/2Qfesx4M5tOuH6YayFIPJl5UupWm1Hajm8M6rZOpB+qZzwMQqvvVqyFARjdg4ST3upIbAhmukzNye7ZAK4BYYzXMZmxPptOtHuVE+2ld5CJyUwyRuiQGdSRYTwzNGSdGtgH3RHP1zfHx17BsC8hUExa7xoWFOl2GHRtLtd/FV44cjAIKPad/PIn6+38GhCOkR2PYR2f7Wh5UkZemiBisOZk91wQr5QZ2OEIQ/j+z82mE9+X7cOrXPFo+gHZ9ENFvSurCm8hZ5LK8zDwdDsCZ+cimHADAeO82nlYe6VaIUoEKUxCMW6jsJ0E64owJdPQtJ2XEtFsk35o9KXHgA3GymwjFgaVbmefE17bu8HuW6viSsTM/wdY01XjTJQJIuDd//iX9uKYdS8ISVmmF1yg+bzejraHZPvwKheflPksxSDG+6RX2R3t1R7M0sOWE5QtPjO8X3H6AxvTsusTvy43nq7fm5OZk5mwSjq0ofD6nqa8ffqbTxz2rqpeWghSUkLX5Lb+Zez0d3/yqc2qk3MjH5/SMxbbN68AcJ5JP1RATKTbAfGtdZvHXRxUuh1ND9k/2eDv6HzIaiWIAFfH9gjmTbZtTcutb/2pm0Wuo41IGAFraI1s+qHCg0vh1EPHJArLW0kLBvfYwMlBpttpmtT9RbLsB6XDqwukfsrm+um640y0E+SD3aTrDIBuBEG6HBYDPxjsy1+46ceHb9O2fkbpSKQfqh8Tu5kIZwYxXtTGYMb3BvvzcyoKb8YWEF3Y09F6jx94+kYQoayI2xiTtx8g4FhZ5cN6olmWvRZE+8jovSOyN6j0QyrehYVNp9e2aXqQO7ZqwsDiXvl0f8w65Z3HWjbK2MmNjK8EKSkQT2ZmAnydrKetk4KScFNs8+6XBvVOvOfk1/ccZ2+9lYhOdQNkxbZh3NeHullBpdsRKWfz47ddy8AFst98zPyXosewllLPo9kuEIIIBXR42jqnKuCvBZX6Xuiteozt1IghhVDVXVpPR/EZPcegXh4MhTso+yHZpOXFXSNQj+HACFI8H7HiyW5R+mCJrKetUzyFaGl2c+tVfhdPKRlfxwmLl4Xkf1t+iPut87I/av2z/2MViig1je9eROAF0kWURKk18MJsOiFS1Abi+yWwCZggBXPIOp0NN2bgjo+O54DaGX0p8YGAXRZ4lTOqMNLtVKqtS2tN1k7qDx5Rmm185nIRR6DyVAHx5T0diRuCeqqIY+z6fP+9Uo6a6qhJ9+DXMejICmmJyxlktq4JotTaSPMIjyBFjbwEvow0CQ4hkq2pPXO6ZbEIEJogs2oLd3HFRDojWEFH8RmA37MJ5+fWta2R0VNGRs/3ZrCl1iJLEEcxpzQbXQ3iubK+USIWmsmam+tovVPGqDIyOo6xZcZ1L8M/6YvFpvt5DLqzLk3JrnMIWElEu7vX84OWYfh+jaZn6DvIcOW0+EYF7fgovqnEoiBaIet16hQBElUbYDmlkcX1iUq6nTC8pJ1XT7tf5AOQvvMC8AbnMTVI369yJI4UQYSyWnyjRBY/smZmO1ofKAeArt/3aX/lgAZr6D4An5fuU0NmFWb8PD9kzQgszqZwFD6NyL5NPtul4x+zCo0T5kehaM5w+0WOICXl1Ivp6PXqdLfomZrauy8gi5cSaKw7GT2txOUZ2Lok29kiFmogeVV1HH+H4SnhBfHIEkRMwimmQ4M3AzTDy6SGt9UVF+BlfJESCSzc6OkIL3KybcM4pFC9QBVzZcZdg/35C4Ly/ZLBN9IE2bGbJLu/QrDvlfWNKvQTdAUjtuKp7vnEWCx7KVrWoIztQR9zFx5aQ7cAOL2sfiM1CMFbW1bXiiCImJzwjdqDt96hVEyH0ZsnnhKoK7dP6YfCuCgVDoYxpkfka0g6u0bki+ZUxDfISIxXLaYTRjCQcLWIj99wGWBfLn0pugMQHgTTkp4trcuCcrUp1rRfDqaZ0g6GFVQ0p6IJIpTXUUxHOD7mbWvqxvUtv5Hdfr3KKV+KBp5uB9DiYOhTMJNX/GXaK79iNbVnvkWEeUQ4CMyvM+hnNtsrezsPe0VGIS8yGm6z8wRrWU+278qg0tg4l6L9uBIWX+Q2/RCDg9fTSZPUuJiBi93q+de248026PxcR2K1F7vKtHVyn4HnMdMXibA/gJcBWqEaSCVPkCkca97e/SgIqV0AU3gNSLcu9dtHSsttdghP5niq+ygw31/O9ZuZXyGm6T2diedkFo6MjI5Ee6L8gd/BTMXDF6s52X3pSNkzmfH9bDrxLRkchIw0QcTtsUX03dEHDi5va3Mqcx4zL5d1cQAwwMCibEfrCr9JvQMzsZsM4DLhBr6L1KgDzLQ0m+tbGtjuJhJ/i5M3QORQbpBZVI7LDzAvl267Q0bei4zb43S28fVsZ+JRL32X2koTJJ7qeolAba4GZZrXk2693lVbhUZanORCcHx0vqsmZfaPEZwQ37zFb/V2tPUoQOFZVGBXV59/VOXuJsj7GC9JCxn4UbYj8RXPoKjsIPFkZoun0meMX9qDjSf7X3GIreZUZg5YOD/KlT8ohnReFGQRGBnj6ZJpTmW+U9x9ZYsPBVb+QKaimCjBkU23HSKDl/wOkuzK/lVlqTIaOAsPmNeTbivzaiYzlQ/LaAnUCew9Wn2+Mj1o+X4Dv2BbdafkHj/09zI6eJFpTnadywVPYU9EZuC32Y7E33oZS/kVqynZtdIikqweFVCqUXH/MGHDpQT7ctnyB2HEU8gY0qtMoZ4fi3LaUvEsQPE+phIOYhiLetKJq7xipPSR3px8ZSIw+MzOdeHcK8Hv2UwX5tIJ4QHr65/y/UMxMZmVt6fpSGfp62TLdK7jDgkBnvo1JTPftMgJTNtTBjcGfm/b9UfLJpSTfsUSygqSMIbWEeHvZZQXMgx+HP3WWb4nECicGC0BcJFCUJaWhMiyWKnKOQ6GxGtl89469zGM5T257Vf4fbK273Gvfryuof97BJosO29mPDcAbn873bZJtg8lghQGZXEOfRmIF8q+xgiPW5vozN6ORKfsRNzKiaAsWFhb7v5h1P4Yq/tQNzOoXFJu5zZSO+FgOIYGVxHoNNm+gvQ8UHUn0vn6p4EgBcj1vMbw/VutcbPeW3fAe7KGdCOnw7dIZCNkjp2S7Tz0F27GDKuNalyN47sGuqVuy26X+J20r5is7zYimiaLlzixGiI6UVf1K20EcSbkxJZDVJcVua8sqUkG6Aqtmv6ysHhwOxonXBS1SDgRmckDm1cS41x5B8PgElmLBNZK6V5FHRNgRbYBi3TWMdFLkCIjNMWW3znQZ8/1O5hGU8LqN4by1teCdHwc7eGjA3/hojHYn58dEP43EEHaHcTPWHZfCOK8ck3pGUvbt1wP4nOldpLCB3xgqfjVn2Cch00rsr39i/z+gB0RzyOer4/Hx4jjTOmDiCBLT+jYwZnwXWqYMM+vHdw3gpSMqPwODNgE3BxE4urCO/C224nwDVlSB3kEOlxHLQ6GzGu3WuNmBvENqJrAOqhvQN8JIoxYe6coCLCGuONaswDAFdKniAEGM+mIL0GAp4iBEGTHbqLhHJ7ZKUO8xO/XGC0XavDXm9mtN2uZI+t0nuvPlL1Ic73TaijDHUYCjkAJIsDUsvCCvMlVdMlgcB9s62K96XiY4qnMLADL5NML8XvM1qxsuvV+14tcsqGO1z+dhTm9TCNwgpSUa5rcdZrFEL5AUi4EIn7DZlqcS7dc53f8hhanPsYv++qsKappQIUuY4dskTjhaC+G/nDbgHzhwFZTcsPFFvFi2fgS4QsXFJF3hWdoBHG+TTSUaIPPrzHDQSt6k66QDspibLEZF+Q6E/fKLO7mVPcMMN8kW/eRga1sY26uM/E9mfG9yOh4/QsuKnHkmYVKkJJaqtGAzmsMcEm2I3Gr31kFtQRleUxioOm1NKh4HIonM+eDcK3s61+QUYnlSB8JgggldSw8BBmUldwwG2ARlDWmHMi7+t1tMRtVvyTx8GCbLs11tooMlb6mJJUJZtoZmyCjEt3YLTIEKSgriq6olmjD+2Cene1su8sNACpttARljXD34NzJ8LZVBJwir6O/p2jD9YqnMmeBIW7E95DSN6QSa+V0jRhBCurqWHgIqgzCsVzXPL57gYo3s7i9Zq6bWnJ8VL3Vdw4wbL4y15lY5vcBhih70GD3rQXoS+UW20i/h5El0q2ukSSIo7yGwo/iNYZszOzpTDzoFhDZdk2TM5+xbNwPQqtsHzZwOzHqVPySRHjpkE2nvtXZ2i2rh1u5eKr7FGL7NhDt5VZmeLswCrJ61TO6BCnORNPNa5ry9um+RwMKX6iJY5Z4SQrn1WAjPoUDTC6npewBR6PEWjn8I08QMQFNxecDiwbUQupylhv2e5DBTKplD0SJNWLc1NOIBTrd0j3A5alpRRCkNCNV70+nH8Z9faib5Xc0YDEo6zowzZKNxyhnSWexBeTI6ZQ9wNBtIEwvp9cou1xg3tmyOu4sV1EEEco78RtjYzcRcJY0CAFGA2oh9a4n+kYePC2IUg6qHtnOcymg+BLpNTGCYMURpDQP1ZMeEQ1IoDu4cfxcv2IJSrpqIfWHv27v4MY95/itt46YniDjS3STQ/RXsQQRymspqhNgZVVVUgcVAyGw1RSVWFHFcnZFsIomyAffJpn2GHi1rOOjU5sbfEO2gS7z+8NR+gIwqBiIKZmGpu28lIhmy+YVcOsl4McTX3efVUEQ59tEy4VVcEePbl1IgoyB0JOZBk/ZXD/d9/gS3Uyotm+QkfCJt3edCaIbZV0enMsr4JrslsTVfpc4K+uEyAjm/sZJ0dq9EMyXSpeIY2wB0YWqBWsCWveuh6maHWT4jLU4zTFe5FjspCCSMje1d02yLPoWmI9hwiCBnrWZ78yl255wbUnJhlrcejTFukhOwVexqiRIATFWdruG40CHRdl060q/fZp8tfIuO9fgGOpLtGTwSIw2YhUTpDBtTYE7z+YHrakbn2z5Y7TMJ6eNltCCAAPV5GapR6rqCVLcTUatY+cGymJRnfk9HYlVbtpHtU08mZkJ8HVea2wMm09gnsJRwLBGCFKAWiQPqGN+jIgOlgU/CmGgMrprCW8OMFmGzBz9kKkpgjgAaiiDgAo7sVGPZQ+u7IEfi1ylz9ojSBEtTTfFkT7zL3uM7GLlBOkp7EKdwJvULEEE0sLXCNs3rwBwnqzHbVRvjSemuqZaIBGy+1GZVeVkrie+rW7zuPl+lz2Q0S8omZomSAlkHd6qAD/0Po07x++8tuUWho5gJuHzlSeeEoSncLn5hP27IUjRAjriHcL2XFUNZipCcW8f153vd7xM2Avf7fiGIDshpWORMfPdg/32+X7X1iip7pCbBkVanxluDb9zuyB9vmR1DEPOEGQXqOt4TRG1TWDXneZ3iTYtr4dB+XyFscIVxzQEGQXAeLL7VCJbZGuUyh9cLNG2Co0T5usObioeMCwH8B3ZAwYwv8tkzcx2tD6guI6qVtwQpIxptVywaQ7K0nFEHVjesAqnjiGISwM2JbvOIWClbOLqQlCWYpFJDUVSg0xg7RLaSDczBPFgHh1OfqJMMYCTsum2lzwMraXMdnC5i73MLNptDUE820e4iWfmEkiUu270LO4I8CDDujq7uWVp2aAsJ5hpw6UE+3LZEmtg9AO4rCfdeqPfCazl8IiulCGIpG10BBqVy0kbxBiS068ZMUMQFVPrCVXtB+jynnSLeLqL7xQny31zKjMHTKK8gtQuVch7a13lapdSwaDKZQ1BNBi4aVLmcLLwr0Q4ULY7URdjiGIn0wBzrN5+iICjpPuS/M6RHa+a5QxBNFnXSTU6/i9LiPgi2S5FZSUCxWSL8jh7D2N5Np24WFYHI/dhBAxBNK8IH1ONltP0Dc5janZ94tflGprf3SNgCOIeK9ctnVSjY2Ii9dDZroVUGjIHkopURcVKlTUE8dFyyqlGy+m2U2Wqcs3N794RMATxjpknCSfVqL3tdiJ8w5NgmcbMfP9Wa9yssONPdM4pin0ZggRkFbepRsupE9UIxnJ6V+rvhiABWk41Rpw91lcPcGpVO5QhSAimbU52nX8VIe0AAADeSURBVAHQjSCMdzc8b7ZB5+c6EqvdtTetdCFgCKILSY/9uM0fXKl5uDzCEdnmhiChmoYpnsrMArCMQGOHq1ItmRxDhVfD4IYgGkBU7UJ8m8RocDoTH0OMQYCezXP96mqpsaGKT5jyhiBhom/GjjwChiCRN5FRMEwEDEHCRN+MHXkEDEEibyKjYJgIGIKEib4ZO/IIGIJE3kRGwTARMAQJE30zduQRMASJvImMgmEiYAgSJvpm7MgjYAgSeRMZBcNEwBAkTPTN2JFHwBAk8iYyCoaJgCFImOibsSOPwP8D4WLpm9gmyWcAAAAASUVORK5CYII=
// @include      *://wenku.baidu.com/*
// @include      *://a.1000wk.com/*
// @include      *://www.wocali.com/tampermonkey/doc/*
// @include      *://pan.baidu.com/s/*
// @include      *://yun.baidu.com/s/*
// @include      *://*.docin.com/p*
// @include      *://pan.baidu.com/share/init*
// @include      *://yun.baidu.com/share/init*
// @include      *://www.bilibili.com/read/*
/*************** 解除网页限制 *************/
// @include      *://b.faloo.com/*
// @include      *://bbs.coocaa.com/*
// @include      *://book.hjsm.tom.com/*
// @include      *://book.zhulang.com/*
// @include      *://book.zongheng.com/*
// @include      *://book.hjsm.tom.com/*
// @include      *://chokstick.com/*
// @include      *://chuangshi.qq.com/*
// @include      *://yunqi.qq.com/*
// @include      *://city.udn.com/*
// @include      *://cutelisa55.pixnet.net/*
// @include      *://huayu.baidu.com/*
// @include      *://tiyu.baidu.com/*
// @include      *://yd.baidu.com/*
// @include      *://yuedu.baidu.com/*
// @include      *://imac.hk/*
// @include      *://life.tw/*
// @include      *://luxmuscles.com/*
// @include      *://read.qidian.com/*
// @include      *://www.15yan.com/*
// @include      *://www.17k.com/*
// @include      *://www.18183.com/*
// @include      *://www.360doc.com/*
// @include      *://www.eyu.com/*
// @include      *://www.hongshu.com/*
// @include      *://www.coco01.com/*
// @include      *://news.missevan.com/*
// @include      *://www.hongxiu.com/*
// @include      *://www.imooc.com/*
// @include      *://www.readnovel.com/*
// @include      *://www.tadu.com/*
// @include      *://www.jjwxc.net/*
// @include      *://www.xxsy.net/*
// @include      *://www.z3z4.com/*
// @include      *://yuedu.163.com/*
// @include      *://wenku.baiduvvv.com/d/?url=*
/*************** VIP解析 *************/
// @include      *://www.youku.com/v_*
// @include      *://v.youku.com/v_*
// @include      *://www.iqiyi.com/v_*
// @include      *://www.iqiyi.com/w_*
// @include      *://www.iqiyi.com/a_*
// @include      *://www.le.com/ptv/vplay/*
// @include      *://v.qq.com/x/cover/*
// @include      *://v.qq.com/x/page/*
// @include      *://tudou.com/listplay/*
// @include      *://tudou.com/albumplay/*
// @include      *://tudou.com/programs/view/*
// @include      *://www.mgtv.com/b/*
// @include      *://film.sohu.com/album/*
// @include      *://tv.sohu.com/v/*
// @include      *://www.acfun.cn/v/*
// @include      *://www.bilibili.com/video/*
// @include      *://www.bilibili.com/anime/*
// @include      *://www.bilibili.com/bangumi/play/*
// @include      *://www.baofeng.com/play/*
// @include      *://vip.pptv.com/show/*
// @include      *://v.sosoik.top/v/*
/************************************/
// @connect      pcw-api.iqiyi.com
// @connect		 pan.baidu.com
// @connect		 yun.baidu.com
// @connect 	 cc.infopocc.top
// @grant        GM_xmlhttpRequest
// @grant        GM_getResourceText
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM_download
// @grant        GM_addStyle
// @grant        GM_openInTab
// @require      http://libs.baidu.com/jquery/2.0.0/jquery.min.js
// @require      https://greasyfork.org/scripts/391006-weight/code/weight.js?version=739789
// @run-at       document-idle
// @compatible	 Chrome
// @compatible	 Firefox
// @compatible	 Edge
// @compatible	 Safari
// @compatible	 Opera
// @compatible	 UC
// @license      GPL-3.0-only
// ==/UserScript==

(function() {
	'use strict';	
    var $ = $ || window.$;
    var window_url = window.location.href;
    var website_host = window.location.host;
    
    /*** 未经授权，任何人不得使用本插件代码 ***/
    
    //百度文库解析
    var baiduAnalysis={};
    baiduAnalysis.addHtml=function(){
    	//只有百度文库才能通过
    	if(window_url.indexOf("wenku.baidu.com/view")==-1 || website_host!="wenku.baidu.com"){
    		return;
    	}
    	//iframe中不再执行
    	if(window.top != window.self){
    		return;
    	}
    	
		//左边图标追加
    	var topBox = "<div style='position:fixed;z-index:999999;background-color:#ccc;cursor:pointer;top:200px;left:0px;'>"+
						"<div id='crack_vip_document_box' style='font-size:13px;padding:10px 2px;color:#FFF;background-color:#25AE84;'>下载</div>"+
						"<div id='crack_vip_search_wenku_box' style='font-size:13px;padding:10px 2px;color:#FFF;background-color:#DD5A57;'>网盘</div>"+
						"<div id='crack_vip_copy_box' style='font-size:13px;padding:10px 2px;color:#FFF;background-color:#FE8A23;'>复制</div>"+
				 	 "</div>";
		$("body").append(topBox);
		
		//提取目标文档标题
    	var searchWord = "";
		if($("#doc-tittle-0").length!=0){
			searchWord = $("#doc-tittle-0").text();
		}else if($("#doc-tittle-1").length!=0){
			searchWord = $("#doc-tittle-1").text();
		}else if($("#doc-tittle-2").length!=0){
			searchWord = $("#doc-tittle-2").text();
		}else if($("#doc-tittle-3").length!=0){
			searchWord = $("#doc-tittle-3").text();
		}
    	
    	//为每一页添加复制按钮
		var onePageCopyContentHtml = '<div class="copy-one-page-text" style="float:left;padding:3px 10px;background:green;z-index:999;position:relative;top:60px;color:#fff;background-color:#FE8A23;font-size:14px;cursor:pointer;">获取此页面内容</div>'; 
		$('.mod.reader-page.complex, .ppt-page-item, .mod.reader-page-mod.complex').each(function() {
			$(this).prepend(onePageCopyContentHtml);
		});
		
    	var defaultCrackVipUrl = "http://www.wocali.com/tampermonkey/doc/download?kw=@&wenku_url=#";
    	$("body").on("click","#crack_vip_document_box",function(){
    		defaultCrackVipUrl = defaultCrackVipUrl.replace(/@/g, encodeURIComponent(searchWord));
    		defaultCrackVipUrl = defaultCrackVipUrl.replace(/#/g, encodeURIComponent(window_url));
    		GM_setValue("document_url",window_url);
	    	window.open(defaultCrackVipUrl, "_blank");
	    });
	    
	    var defaultSearchWenkuUrl = "https://www.quzhuanpan.com/source/search.action?q=@&currentPage=1&o=36";
	    $("body").on("click","#crack_vip_search_wenku_box",function(){
	    	defaultSearchWenkuUrl = defaultSearchWenkuUrl.replace(/@/g, encodeURIComponent(searchWord));
	    	window.open(defaultSearchWenkuUrl, "_blank");
	    });
	    
	    $("body").on("click","#crack_vip_copy_box",function(){
	    	baiduAnalysis.copybaiduWenkuAll();
	    });
	    
	    $("body").on("click",".copy-one-page-text",function(){
	    	var $inner = $(this).parent(".mod").find(".inner")
	    	baiduAnalysis.copybaiduWenkuOne($inner);
	    });
   	};
    baiduAnalysis.showBaiduCopyContentBox=function(str){
    	var ua = navigator.userAgent;
    	var opacity = '0.95';
		if (ua.indexOf("Edge") >= 0) {
		    opacity = '0.6';
		} else{
		    opacity = '0.95';
		}
    	var copyTextBox = '<div id="copy-text-box" style="width:100%;height:100%;position: fixed;z-index: 9999;display: block;top: 0px;left: 0px;background:rgba(255,255,255,' + opacity + ');-webkit-backdrop-filter: blur(20px);display: flex;justify-content:center;align-items:center;">'+
    						'<div id="copy-text-box-close" style="width:100%;height:100%;position:fixed;top:0px;left:0px;"></div>'+
    					  	'<pre id="copy-text-content" style="width:60%;font-size:16px;line-height:22px;z-index:10000;white-space:pre-wrap;white-space:-moz-pre-wrap;white-space:-pre-wrap;white-space:-o-pre-wrap;word-wrap:break-word;word-break:break-all;max-height:70%;overflow:auto;"></pre>'+
    					  '</div>"';
    	$('#copy-text-box').remove();
	    $('body').append(copyTextBox);
	    $('#copy-text-content').html(str);
	    $('#copy-text-box-close').click(function() {
	       $('#copy-text-box').remove();
	    });
   	};
   	baiduAnalysis.showDialog=function(str){
   		var dialogHtml = '<div id="hint-dialog" style="margin:0px auto;opacity:0.8;padding:5px 10px;position:fixed;z-index: 10001;display: block;bottom:30px;left:44%;color:#fff;background-color:#CE480F;font-size:13px;border-radius:3px;">'+str+'</div>';
   		$('#hint-dialog').remove();
	    $('body').append(dialogHtml);
	    timeoutId = setTimeout(function(){
	    	$('#hint-dialog').remove();
	    }, 1500);
   	}
    baiduAnalysis.copybaiduWenkuAll=function(){
    	baiduAnalysis.copybaiduWenkuOne($(".inner"));
    };
    baiduAnalysis.copybaiduWenkuOne=function($inner){
		//提取文字
		var str = "";
		$inner.find('.reader-word-layer').each(function(){
			 str += $(this).text().replace(/\u2002/g, ' ');
		});
		str = str.replace(/。\s/g, '。\r\n');
		
		//提取css中的图片
		var picHtml = "";
		var picUrlReg = /\(((\'|\")?https.*?)\)/i;
		var cssUrl = "";
		var picNum = 0;
		var picUrlLengthMin = 65;
		var picTemplate = "<div style='margin:10px 0px;text-align:center;'><img src='@' width='90%'><div>____图(#)____</div></div>";
		$inner.find('.reader-pic-item').each(function(){
			cssUrl= $(this).css("background-image");
			//在css中的情况
			if(!!cssUrl && (cssUrl.indexOf("https")!=-1 || cssUrl.indexOf("HTTPS")!=-1)){
				var array = cssUrl.match(picUrlReg);
				if(array.length>1){
					cssUrl = array[1].replace(/\"/g, "");
					if(!!cssUrl && cssUrl.length>picUrlLengthMin){
						picNum ++;
						var onePic = picTemplate;
						onePic = onePic.replace(/#/g,picNum);
						onePic = onePic.replace(/@/g,cssUrl);
						picHtml += onePic;
					}
				}
			}
		});
		
		//如果还有img标签，一并提取出来
		var srcUrl = "";
		$inner.find('img').each(function(){
			srcUrl = $(this).attr("src");
			if(!!srcUrl && srcUrl.length>picUrlLengthMin && srcUrl.indexOf("https://wkretype")!=-1){
				picNum ++;
				var onePic = picTemplate;
				onePic = onePic.replace(/#/g,picNum);
				onePic = onePic.replace(/@/g,srcUrl);
				picHtml += onePic;
			}
		});
		
		//追加内容
		var contentHtml = str+picHtml;
		if(!!contentHtml && contentHtml.length>0){
			if(picNum!=0){
				contentHtml = str+"<div style='color:red;text-align:center;margin-top:20px;'>文档中的图片如下：(图片可右键另存为)</div>"+picHtml;
			}
			baiduAnalysis.showBaiduCopyContentBox(contentHtml);
		}else{
			baiduAnalysis.showDialog("提取文档内容失败了");
		}
    };
    baiduAnalysis.download=function(){
    	setTimeout(function(){
    		if(website_host.indexOf("a.1000wk.com")!=-1){
	    		var $searchbox=$(".search-box");
	    		if($searchbox.length>0){
	    			var baiduwenkuUrl=$searchbox.find(".doc-input").val();
	    			if(!!baiduwenkuUrl){
	    				$searchbox.find(".btn-search").click();
	    			}
	    		}
	    	};
    	},500);
    };
    baiduAnalysis.removeAd=function(){
    	if(website_host.indexOf("wenku.baidu.com") != -1){
		    setInterval(function(){
		    	$(".banner-ad").hide();
		    	$(".union-ad-bottom").hide();
		    	$("iframe").hide();
		    	
		    	//VIP去广告小按钮
		    	$(".ggbtm-vip-close").hide();
		    	$(".ad-vip-close-bottom").hide();
		    	$(".ad-vip-close").hide();
		    	
		    	//搜索页面
		    	$("#fengchaoad").hide();
		    	$(".search-aside-adWrap").hide();
		    },300);
	    }
    };
    baiduAnalysis.init=function(){
    	baiduAnalysis.addHtml();
    	baiduAnalysis.download();//百度原文档下载
    	baiduAnalysis.removeAd();//移除百度文库中的广告
    }
    //百度文库部分初始化执行
    baiduAnalysis.init();
    
    //如果与百度文库相关，则执行至此
    if(website_host.indexOf("api.ebuymed.cn")!=-1 
    	|| website_host.indexOf("www.ebuymed.cn")!=-1
    	|| website_host.indexOf("a.1000wk.comn")!=-1
    	|| website_host.indexOf("wenku.baidu.com")!=-1
    	|| website_host.indexOf("wenku.baiduvvv.com")!=-1){
    	return false;
    }
    	
    /////豆丁文库开始
    var doudingAnalysis={};
    doudingAnalysis.judgeWebsite=function(){
    	if(website_host.indexOf("docin.com")!=-1){
    		return true;
    	}
    	return false;
    };
    doudingAnalysis.addStyle=function(){
    	var innnerCss = 
		`
		#plugin_doc_analysis_douding{position:fixed; top:160px; left:0px; background-color:red; z-index:999999;color:#FFF;}
		#plugin_doc_analysis_douding >.plugin_item{cursor:pointer; padding: 10px 2px; font-size:13px; text-align:center;}
		#plugin_doc_analysis_douding >.douding_download{background-color:#6DB324;}
		#plugin_doc_analysis_douding >.wocali_jump{background-color:#337AB7;}
		`;
		$("body").prepend("<style>"+innnerCss+"</style>");
    };
    doudingAnalysis.generateHtml=function(){
    	var html="";
		html+= "<div id='plugin_doc_analysis_douding'>";
		html+= "<div class='plugin_item douding_download' title='豆丁文档免费下载，支持doc、pdf、txt'>下载</div>";
		html+= "<div class='plugin_item wocali_jump' title='嚓哩文库，300W文档免费下载'>文档</div>";
		html+= "</div>";
		$("body").append(html);
    };
    doudingAnalysis.operation=function(){
    	var defaultCrackVipUrl = "http://www.wocali.com/tampermonkey/doc/download?kw=@&wenku_url=#";
    	var searchWord = $(".doc_title").text();
    	searchWord = !!searchWord ? searchWord : "文档";
    	$("body").on("click", "#plugin_doc_analysis_douding .douding_download", function(){
			defaultCrackVipUrl = defaultCrackVipUrl.replace(/@/g, encodeURIComponent(searchWord));
    		defaultCrackVipUrl = defaultCrackVipUrl.replace(/#/g, encodeURIComponent(window_url));
	    	window.open(defaultCrackVipUrl, "_blank");
		});
		var wocaliWebsite = "https://www.wocali.com/s/search.action?q=@&currentPage=1"
		$("body").on("click", "#plugin_doc_analysis_douding .wocali_jump", function(){
			wocaliWebsite = wocaliWebsite.replace(/@/g, encodeURIComponent(searchWord));
			window.open(wocaliWebsite, "_blank");
		});
    };
    doudingAnalysis.start=function(){
    	if(doudingAnalysis.judgeWebsite()){
    		doudingAnalysis.addStyle();
    		doudingAnalysis.generateHtml();
    		doudingAnalysis.operation();
    	}
    };
    doudingAnalysis.start();
    
    //与豆丁文档相关，执行至此
    if(website_host.indexOf("docin.com")!=-1){
    	return false;
    }

    //////VIP解析开始///////
    var vipVideoAnalysis={};
    vipVideoAnalysis.analysisWebsite="http://v.sosoik.top/v/s/?url=";
    vipVideoAnalysis.judgeVipWebsite=function(){
		var isVip = false;
		var host = window.location.host;
		var vipWebsites = ["iqiyi.com","qq.com","youku.com", "le.com","tudou.com","mgtv.com","sohu.com",
			"acfun.cn","bilibili.com","baofeng.com","pptv.com"];
   		for(var b=0; b<vipWebsites.length; b++){
	   		if(host.indexOf(vipWebsites[b]) != -1){
	   			isVip = true;
	   			break;
	   		}
	   	}
   		return isVip;
	};
	vipVideoAnalysis.addStyle=function(){
		var innnerCss = 
		`
		#plugin_doc_analysis_vip_movie_box{position:fixed; top:160px; left:0px; width:20px; background-color:red;z-index:999999;}
		#plugin_doc_analysis_vip_movie_box >.plugin_item{cursor:pointer; width:20px;height:35px;text-align:center;line-height:35px;}
		#plugin_doc_analysis_vip_movie_box >.plugin_item >img{width:18px;display: inline-block; vertical-align: middle;}
		`;
		$("body").prepend("<style>"+innnerCss+"</style>");
	};
	vipVideoAnalysis.generateHtml=function(){
		var html="";
		var vipImgBase64 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADICAYAAACtWK6eAAAPpUlEQVR4Xu2dd8w1RRXGn8doNFEDKIgRomKJIDFKs0dQUJRiQcCoCIoYpVkBDUgAxaCCIghq7ChIR8ROREEDsWEhImJDg4KCPWrsxxzY7+N7y713d8/szNy9zyTvX++cc2Z+Z587uztlCRUREIGJBCg2IiACkwlIILo6RGAKAQlEl4cISCC6BkSgHwGNIP24yWpBCEggC5JodbMfAQmkHzdZLQgBCWRBEq1u9iMggfTjJqsFISCBLEii1c1+BCSQftxktSAEJJAFSbS62Y+ABNKPm6wWhIAEsiCJVjf7EZBA+nGT1YIQkEAWJNHqZj8CEkg/brJaEAISyIIkWt3sR0AC6cdNVgtCQAJZkESrm/0ISCD9uMlqQQhIIAuSaHWzHwEJpB83WS0IAQlkQRKtbvYjEBaIme0N4Nx+4WUlAoMS2Jvk+ZEIEkiEnmxrJyCB1J4hta8oAQmkKH4Fr52ABFJ7htS+ogQkkKL4Fbx2AhJI7RlS+4oSkECK4lfw2glIILVnSO0rSkACKYpfwWsnIIHUniG1rygBCaQofgWvnYAEUnuG1L6iBCSQovgVvHYCEkjtGVL7ihKQQIriV/DaCVQhkB0AHFs7KbVvIQkcQ/KKSM/D+0EiwWUrArUTkEBqz5DaV5SABFIUv4LXTkACqT1Dal9RAhJIUfwKXjsBCaT2DKl9RQlIIEXxK3jtBCSQ2jOk9hUlIIEUxa/gtROQQGrPkNpXlIAEUhS/gtdOQAKpPUNqX1ECEkhR/ApeOwEJpPYMqX1FCUggRfEreO0EJJDaM6T2FSUggRTFr+C1E5BAas+Q2leUgARSFL+C105AAqk9Q2pfUQISSFH8Cl47AQmk9gypfUUJSCBF8St47QQkkNozpPYVJZBEIGZ2bwCPSNCT60nenMBPZxdm9nAA9+lsuMyA5OWTfJjZRgC2DMa4luStER9m5of9lS7/BnAzyZ+Xbsi0+KkE4om/JUFHzyD54gR+OrswsxsBbNrZcKnB1SS3nSKQvQCcF4yxF8kLIj7MzCL2A9j+AcBNAH4M4FIAl5H86QBxOrtMIhCPamYXA3hW5xYsNfgrgI1I/iPop5O5me0I4EudjFavfCjJ06YIZG8A5wbjjFEgqyHxH6zPATiN5A+CzHqbpxTIcwBc1LsldxjuQ/KsBH5auzCzMwDs29pg9Yp+y+Di/vPAAgkfyFzhCDINvY92ZwM4iuQvgjnqbJ5SIHcG4PfG63duxVKDS0nuHPTR2tzM7grgdwDu0dpo9YoXktxzaqbNUowgiyaQNUj9B+j9AI6LPoN1yXMygTS3WacAeGWXBqxS978A7kvSL9rBi5m9EMCZCQLtTvIzEkgCktNd+PPKriS/PngkAKkFshWA7yRo+GEk35HAz0wXZvZFAE+bWXF6BR85NyY59eHXNIIEMa81/ycAH0kvSeVwkp+kAmlGkesAbB5s+DUkHxn0MdPczDZs3r5FOZxE8vBZASWQWYQ6/d9/jA4i+b5OVh0rRy+MFeHM7DUA3tmxHatV34LkjxL4mejCzA4DcGKCGJuTvH6WHwlkFqFe/z+E5Om9LFsYDSEQ/1X+LYA7tYg/rUqrX+VIDDP7IYAtIj4AfJvkdm18SCBtKHWu48+s25O8srNlC4PkAmlus1LMidxKMjyzPYmBmfkt3PdaMJpVpfUvmAQyC2Xv//uD+7Ykb+jtYYLhUAJ5NoBPJmjsziR9ZjV5MbOTALwu6Hjm3Me6/iWQIO3p5n6Luw3Jv6WMMpRAUs2JnEVyn5QdbkY4v/37jU/sBX2fT9LnNloVCaQVpkilU0i+OuJgue0gAmkuwncBeFWwsb7kZMPUvwpm5hORXwi2zc39fbwvh2hVJJBWmCKVfETfjOSvI07WtR1SII8C8N0EDd2P5McS+Fnrwsx8KcsLgj5bzX3oFitIubt50gWvgwmkGUVSzIn4ys6dunNa3cLM7t4sLblb0OeJJI/o4kMjSBdavev+z99MkvSVweEytED8fvDkYCt9QmhTkr4cOlzMbD8AHw07AlrNfWgESUC6u4vTSR7S3WylxdACSbVP5AiSKSb0fFm+L2v35e2R8g2Sj+3qwMzGsh/EN4Ud17X/y+r7CP6wZh7q0QB8mVKqciPJ+6dwNqhAvIFm5q97/bVvpFxH0nf8hYqZ3Q/ArxKsQfMlDu/t2pgR3WJ1ens3i5OZ+XX4egBvBuBvQFOUrUiG57lyCGR3ACkWlYU7bGaehLcmoL8ByT919TOiEeQ8ks/r2v9Z9c3MR2WfZN54Vt0W/z+a5PEt6k2tkkMgHsOXnkTnHE4m+dpIhxMtLel9cWgEmZ09M3sygC/PrjmzRuslQNM8DS6Q5jbLH9SjEzj+WtX3ifhbis7FzLbxdVOdDVca7ELy8338SCDtqJnZewAc2K72xFpGMroeMO1+kElNNTN/GEuxMjdycaaYuOw897EuEwmk3SVvZg8EkGJdVa9b4XVbmWUEaUYRnzT0ycNIOZtk5wk+M0u1tORtJN/QtwMSSHtyZuaz4f5SJVIeGj0dJadAfNmJ/4pHSq+lJ2a2K4Cp22FbNqrz3IdGkJZkl1UzM98G7duhI+Vx0a25OQWyAQBflhwtLyHZaaLPzM4BEH3r0mvuY5lAxjIP0vtFRdvkm5k/g/izSKTsRvKzEQfZBOKNTDQncjlJf9PRqiRcWnJgdHunbrFapey2SmZ2FIDoa9qnkPxK+6gra+YWyDMBfCrSYGfXZemJmR0A4APBmJ32fUyKJYG0z4KZXQhgj/YWq9YMb9vOLZBUcyJHkjyhDTwzuwLAk9rUnVLnHJLPD/rwX8WxnIuVdCZ9Na5m5ofEPSDIfP1pB/m18Z1VIM3Q6Qc6+MEOkXIDyQfNctAsLUmxN+DpJP14oFCRQNrhM7MUO1L/Q/Iu7SJOrlVCIKnmRLYjOXXiz8ze2KzviXC6ieQmEQdrbCWQ2RTNzFn7Nol7zq49tcbPSD4k6CPPROHyRpqZHy4XXb15KsmpOxbNzE8If3AQ0gkkjwz6uM08kUBqOLx6kFssM/NDOvx1fKtTYmbk5BMko6+JiwnEjyf1Y0ojxRcL3nvS0hMzewyAFMdT+hbOJIcmJxJIDWfzJheIme0PwE/TjJ7tvOaa2oNk+OCQ7LdYzS/pvQD8PqKOxnbie24z888QHByMcRXJJwR9rDXXat47SJqZHxbubB8PYBc/ticVZwB+somfZRD+jEYRgTQi8U8l+CcTImXVCSszS3WqystJ+oniScqIRpAkPAZ0kmyEKymQ3QB8OgGkFa/yzMw/5OP7CqJlPZJ/iTpZYz+iESQVkqH8PINkilNryjyDNCNIqjmRl5H84LqkE00y9VoYOS3jGkGG0sMSv0lvi4uNII1I/KEstAkKwNdIrp0INLP1mg/5RN+BJz/VUQLJIpCtSaY4buq2xpYWSKo5kU3WnHpiZq8A0Hm/+LLUJZv7WDayjWUmPcuV3iPIxSSjz7VLwhYVSDOKXA1g6x4w1jVZu//YzPyUb38zEinJ5j4kkEgaOtn6TlPfjvCTTlYzKtcgkEMBnBrs1G1LTxLuREs29yGBBDPb3vxgktHl8Sui1SAQnxj6Y3sOE2v6xKC/Tz8m6CvpQ54EEsxGO/PwgR6TwhQXSHObdQGA57ZjMbGWTwz6zsHNgn5WvBUL+ltrrof0VCSX+LmEpL/WH6TUIpBUcyIpICWd+1g2goxlR2EKzil8XEDSmQ5WahFIqjmRKKgkC9wmNUIjSDQ9dwzGfitN0k9iHLRUIZDmNivFF5+isJ5K0s/uHaRIIEmw+jorX4g4yJfHlrewJoGkmhPpm4VB5j6W3WJpHqRvdm63O88/m0fSz1fOUqoRSDOK+AYoPwGxRHkLSd9gNVjRCNIb7febb6Jf1dtDT8PaBOLfdHh3z75EzcKHjM1qgBYrziK04v+/BOA/XNFDNzoHXmNQm0BSraPqCuRKkk/satS1vkaQVsT82/W+0ekikr7ztGipSiDNbVaKOZGuUA8g+aGuRl3rj2gE8TOK/UKOlH81Xxr2QzX862H+d03qpSKRBrptjQLJPSfiu8586+7fozBn2Y9oBEm2IWkWs9L/r1EguedEziT5ohyJkEByUE4bozqBNLdZ/j3Cw9J2daK3nUheliOWBJKDctoYtQok15zI4HMf66ZLAkl78ebwVqVAmlHkW4lPuliN5/Ekj84BuunTWCYK9QyS66KZFMfM/MgeX6E7ZBlk38eUPkkgQ2ZzAN81jyBDz4ks2cs+ANsVLnWLlYNy2hjVCqS5JTkfwJ5pu7zW20tJfngg36u6lUBy0k4Tq3aBpPp02nJa2eY+9JCe5kIt5aV2gQw1J/Jxkvvmhq4RJDfxeLyqBdLcZr0dwOHxri7xsCPJFB+r79QsCaQTrioqz4NAUs+JZJ370C1WFdd570ZUL5BmFPlmom9GuLs3kYyefNILuEaQXtiKGs2LQA4CcHoiUlnnPjSCJMpaITfzIpBUcyJfJbl9IdapvjA1yg/olMrJrLhzIZDmNsv3I0ePeNmf5EdmQRnq/7rFGorscH7nRiDDIcjn2cw2ArBlMOK1JH3DUu9iZjv0Nr7d8BaS0Q1TwSbkMZdA8nBWlDklIIHMaeLU7DwEJJA8nBVlTglIIHOaODU7DwEJJA9nRZlTAhLInCZOzc5DQALJw1lR5pSABDKniVOz8xCQQPJwVpQ5JSCBzGni1Ow8BCSQPJwVZU4JSCBzmjg1Ow8BCSQPZ0WZUwISyJwmTs3OQ0ACycNZUeaUgAQyp4lTs/MQkEDycFaUOSUggcxp4tTsPAQkkDycFWVOCUggc5o4NTsPAQkkD2dFmVMCEsicJk7NzkNAAsnDWVHmlIAEMqeJU7PzEAgLpDmE7Ng8zVUUEehE4BiSV3SyWFY5hUBSfJgy0gfZisAkAuFzjCUQXVxjJiCBjDm76luYgAQSRigHYyYggYw5u+pbmIAEEkYoB2MmIIGMObvqW5iABBJGKAdjJiCBjDm76luYgAQSRigHYyYggYw5u+pbmIAEEkYoB2MmIIGMObvqW5iABBJGKAdjJiCBjDm76luYgAQSRigHYyZQXiBjpqu+iUB4P4gQisCYCUggY86u+hYmIIGEEcrBmAlIIGPOrvoWJiCBhBHKwZgJSCBjzq76FiYggYQRysGYCUggY86u+hYmIIGEEcrBmAlIIGPOrvoWJiCBhBHKwZgJSCBjzq76FiYggYQRysGYCUggY86u+hYmIIGEEcrBmAlIIGPOrvoWJiCBhBHKwZgJSCBjzq76FiYggYQRysGYCUggY86u+hYmIIGEEcrBmAlIIGPOrvoWJiCBhBHKwZgJSCBjzq76Fibwf7d59RQuMbLlAAAAAElFTkSuQmCC";
		var documentImgBase64 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADICAYAAACtWK6eAAAOIUlEQVR4Xu2dW8hmVRnH///LKFA7EEHk2E0XZmpSFxGodFEh5BRIhIgaRYcblSgIIUfyohM5RhRdhBoIEoVKEtJFOtBdkiNhdBPO3HSi0IGirnriyffNz/F7v/fZ67j32v8FA8PMs/Ze6/es37vWPhMqIiACOwlQbERABHYTkCAaHSJwBAEJouEhAhJEY0AE0ghoBknjplorISBBVpJodTONgARJ46ZaKyEgQVaSaHUzjYAESeOmWishIEFWkmh1M42ABEnjplorIbAIQczsCgAXALhmJXkZvZtPAThH8vTcOzpLQczsQgDXAzi++TN3jmpfGoEXATwK4EGSLs3syuwEMbPbAJwA4JKorIeAC3L33ESZjSCbZdT9AHw5pbJeAg+QvHUu3Z+FIGbmxxaPaNaYy7Do3g4/NrmWpC/BupbugpjZLQB85lARgYMEZiFJV0E2y6onNXPIjB0ETpO8siedboJszlQ9A+BYTwDa9+wJ+IG7n7TpUnoK4p2+q0uvtdOlEbiE5Jkeje4iiJn5rOGzh07l9sj68vbp10n8WLV56SXISQB+vUNFBKIEuswivQR5Xsce0XGhuA2BO0j6D2vT0lyQzfLKBVERgSkETpFsfi9eD0FuB3DvFDKKFQEnQLL5eG2+QzPT2SuN91QCF7W+ut5DEB2gpw4P1fPbT5re9dtDEO/g1ZVzfRaAnzf3e3lm/8xBZRa1N+83l/rp+u0zOzX3J0ES6Z4D8ACAp0j68wUqHQhsTsD4gbQ/x+PP85QuEiSB6N0ATrZemya0c1VVNrL4j1bJ1YIEmTCKfNY43npNOqF9CgVgZi7JzYVgSJAJIG8l6fBVZk7AzEodd0qQYK67XDQKtk1h5xEoeHFYggRHl2aPIKi5hJmZnzzJPXCXIJGE9riiGmmXYnYTKPTkqAQJDDItrwKQ5hZSaJklQQKJvY+k38+lsjACZmaZTZYgAYBdH8EMtE8hOwiYmd/VcHkGIAkSgNccUqBNCgkQKHC6t3nul3gvVnNIgdwrJEBAggwKKdAthQQISJBBIQW6pZAAATPLfdSh+epBS6xAYhVShkCBi4USJJCK5pACbVJIgECBp0mb514zSCCxCilDQIIEOC7xQC3QLYUECEiQGKTcW5+bT7OBbikkQECCxCBJkACnEUMkSCCrWmIFIA0aIkECiZUgAUiDhkiQQGIlSADSoCESJJDY1oKY2VsBfADAOwC8C8DrAs1UyOEE/gPA3zn2e/98BclfTAElQQK0WgpiZvcAuDPQLIWkEXgOwI0kn41UlyABSq0EMbPHAVwXaJJC8gj8C8CHSZ7atxkJso/QS+9Jqn6a18y+DuBLgeYopAyBv/nyleSfjtqcBAnAri2ImV0GwKf85rfRBLo/csjDJD8hQTJT3ECQHwG4KbOZqp5G4I0k/76rqmaQANQGgvwVwJsCTVFIeQI3k/QfqEOLBAkArymImfmyyk9FqvQh8FWSX5EgGfBrCuLNKvBqmYzerb6qv2X/DgmSMQ4aCPJnAG/OaKKqphP4AslvS5B0gNVP85rZjwHckNFEVU0n8G6Sz0iQdIAtBPEXJOsrUxk5Sqz6HMl3HlVXB+kBsrWXWJvjEL8O4vddqbQjcAPJn0iQTOCNBPEbFH8F4OLM5qp6jMCXSX5tX6hmkH2EGt1qsplF/FqIL7XeF2iWQtII/BvAZ4669nFwsxIkALnFDHJeUm4E8OnCH5MM9HTokL8AeAjAN0j630NFggQwtRZk2yQzew2ASzfPg/hr+Lev4t/+ffX/RtJnhGpFggTQ9hIk0DSFVCYgQQKAJUgA0qAhEiSQWAkSgDRoiAQJJFaCBCANGiJBAomVIAFIg4ZIkEBiJUgA0qAhEiSQWAkSgDRoiAQJJFaCBCANGiJBAomVIAFIg4ZIkEBiJUgA0qAhEiSQWAkSgDRoiAQJJFaCBCANGiJBAomVIAFIg4ZIkEBiJUgA0qAhEiSQWAkSgDRoiAQJJLa1IGb2cQAfOvB9kNcGmqmQ3QTObL8PAuC7JP8YhSVBAqRaCWJmb9g8cvv+QLMUkk7gUyR/GKkuQQKUWghiZq8H8GsAbw80SSH5BG4j+Z19m5Eg+wg1emmDmT0B4IOB5iikHIH3kvQfpZ1FggRg155BzOxjAH4aaIpCyhJ4muR7JEgm1AaC/Nw/CZbZTFVPI3Apyd/tqqoZJAC1gSD/AKAzVYFcVAj5PMnvS5AMsjUF0fdBMhJTpuo3Se78NqRmkADkmoL47s3MP6Cj7xMGclEh5Fskv6gZJINsA0H+oNO7GQnKq/pZkj+QIBkQGwjyPQCfy2iiqqYTeAtJ/4DRoUVLrADYBoJcBeDpQFMUUpbAEySPPHsoQQLAawuyOQ55GIDfg6XSjsBVJH9z1O4kSCAZLQTZSPI4gOsCTVJIHoF/AvgIyV/u24wE2Ueo0a0m22aY2T0A7gw0SyFpBPxLXjeR/G2kugQJUGo1gxyQ5G0APrm5N+uyiRcR/XMA+kzCywy236D3A/GHSP4skPL/h0iQAK3WggSapJBGBCRIALQECUAaNESCBBIrQQKQBg2RIIHESpAApEFDJEggsRIkAGnQEAkSSKwECUAaNESCBBIrQQKQBg2RIIHESpAApEFDJEggsRIkAGnQEAkSSKwECUAaNESCBBIrQQKQBg2RIIHESpAApEFDJEggsRIkAGnQEAkSSKwECUAaNESCBBIrQQKQBg2RIIHESpAApIQQMzsG4OKEqi2r3ALA/6SWa0k+lVo5pV7z90dJkJQ0vbqOmV0P4Pjmz4Vltjr7rUiQQIqaQwq0qVmImd0F4HYAa5HiINvmudcM0mxo5+3IzK4BcD8AX0qttUiQQOabQwq0qWqImd0G4GTVnSxj481zrxlk5gPDzHzWyDmwnXkPJzVPggRwNYcUaFOVEDNzMVwQlZcINM+9ZpCZDr3NMceTM21er2bdQbLpUlOC9Er1nv2a2fMrPyA/jNDdJE+0TJkEaUk7uC8trXaCkiCBMdR8HRpoU9EQM3thpdc59nFsnnvNIPtS0vj/zcyvjj/SeLdL2N05ks0vjkqQmQ0NM/ODUL/uofJKAs2XV757CTKzYaiD80MT8izJK3qkSoL0oH7EPs1s+zb5mbWsW3P8EwvXkHyxRwskSA/qEiRK/UG/MbOXHFpiRdPUKK7RxcHTAPzX+CyAM5ld84PmWsdLD5LsfouNZpDMEVKyekVBzgF4FIA/bHSapEuSVczM5fAr/TWODWYhh2aQrCFSvnIFQVwMPyt2suQyZS1ySJDyYzxri4UF8SXU8RKzxcFOrUkOCZI1nMtXLiiIzxx+5id7KbVmOSRI+TGetcWCghS/63VtM8c2kTpIzxrSZSsXEsRnj2M65iiTGwlShmORrRQSpOgZoLXOHJpBigzpshspJMhHSfop3eyydjl0DJI9hMpuoJAgl5DMvQAIyfFSbrXEKjvGs7ZWQhCS2TmVHC+nMRvm1BGhNyvuJlZAkOy7XiXHK/MjQaYaXjG+gCCnSPoL5pKK5Hg1NgmSNJTqVOopiOQ4PKcSpM5YT9pqL0Ekx+50SZCkoVynUg9BJMfRuZQgdcZ60lZbCyI59qdJguxn1CyipSCSI5ZWCRLj1CSqlSCSI55OCRJnVT2yhSCSY1oaJcg0XlWjawsiOaanT4JMZ1atRk1BJEda2iRIGrcqtWoJIjnS0yVB0tkVr1lDEMmRlyYJksevaO3SgkiO/PRIkHyGxbZQUhDJUSYtEqQMxyJbKSWI5CiSjv9tRIKUY5m9pRKC+Luw1vDGw2zYwQ1IkCCoFmEFBPE3ofvb4Yd+HWiLXGz3IUFa0t6zrwKC1OpN0Tel1Gpkje0uUZBib+2oATRnmzMVZLVyLPUYpMunuHIGfrTuDAVZtRxLFWTYpM1MkGE5R3+wlirIGZKXTOnkUmJnJIjk2AyaJR6DeNOvLP3m8jlINBNBJMeBwbBUQYZM4gwEGZJrzo/fUgXxPl9L0j8pNkzpLIjkOGQkLVkQ/xClS1L0IzE9besoiOTYkfglC+JdcklOkLyv58Aute9OgkiOIxK4dEG2XfO3mT8A4LElzygdBJEce37dRhHk/G5uj01qHaO4kC6jz2DFSmNBJEcgcz0EOQHgrkDblhDin1j2K/tFRGkoiOQIji4JEgR1RJifJPD7w0p8tMbfzP5kfpOO3ILkmAC4hyC3ALh/QhuXEOqS+Bm1rJmkwQwiOSaOph6CXAjghYntXEJ49k2UlQWRHAmjqLkg3kYz81/cyxPaO+cqL5K8KKeBFQWRHImJ6SXI7QDuTWzznKtlPatSSRDJkTFiegniyyyfRS7OaPscq2YtsyoIIjkyR0kXQTbLrBEP1uckiOTIlMOrdxNk0GORuQgiOQrIMQdBRltqZT+nYmb+VpKcIjly6J1Xt+sMsplF/BU1fkvIBQX71WNTZ0key92xmfk9ZTcnbkdyJILbVa27IBtJfGA9uvBTv1lnsLYJMjP/wXgmIc+SIwHaviqzEGQjiS+3/N6m1F/PfX2t+f9FB6eZTT2B8SzJGi+Lq8lsEduejSDn/YK6KFcvgiBwH0m/rlO0TJDklL9uNPc2l6KNH2hjsxPkgCi+7PL3zPqv6Ryvuj/mM17Nx37NzBn43c+HzapnNw+L+TGLSiUCsxXk/P5u3lg+i2VETSkOy/MhfffbWoZ51LjS2C6y2cUIUqS32ogITCQgQSYCU/i6CEiQdeVbvZ1IQIJMBKbwdRGQIOvKt3o7kYAEmQhM4esiIEHWlW/1diIBCTIRmMLXRUCCrCvf6u1EAhJkIjCFr4uABFlXvtXbiQQkyERgCl8Xgf8C3Y9ZQf3uj84AAAAASUVORK5CYII=";
		html+= "<div id='plugin_doc_analysis_vip_movie_box'>";
		html+= "<div class='plugin_item jump_analysis_website' title='VIP视频破解，电视剧可自由选集'><img src='"+vipImgBase64+"'></div>";
		html+= "<div class='plugin_item jump_document_website' title='300W文档免费下载'><img src='"+documentImgBase64+"'></div>";
		html+= "</div>";
		$("body").append(html);
	};
	vipVideoAnalysis.operation=function(){
		$("body").on("click", "#plugin_doc_analysis_vip_movie_box .jump_analysis_website", function(){
			var jumpWebsite=vipVideoAnalysis.analysisWebsite+window_url;
			GM_openInTab(jumpWebsite, { active: true });
		});
		$("body").on("click", "#plugin_doc_analysis_vip_movie_box .jump_document_website", function(){
			GM_openInTab("https://www.wocali.com/", { active: true });
		});
	};
	vipVideoAnalysis.paramsSelectedInit=function(){
		var episodeList=[];
		var episodeObj = {
			"websiteTitle":"",
			"episodeList":episodeList,
			"originVideoUrl":""
		};
		GM_setValue("episodeObj",episodeObj);
		return episodeObj;
	};
    vipVideoAnalysis.getSelected=function(){
		if(website_host==="v.qq.com"){
			setInterval(function(){ //每100ms,检测一次集数的变化
				var episodeObj = vipVideoAnalysis.paramsSelectedInit();
				var episodeList = episodeObj.episodeList;
				var $mod_episode = $(".mod_episode");
				try{
					if($mod_episode.attr("data-tpl")=="episode"){
						$mod_episode.find(".item").each(function(){
							var $a = $(this).find("a");
							var href = $a.attr("href");
							if(!!href){
								href = "https://v.qq.com"+href;
								var aText = $a.text();
								aText = aText.replace(/\s/g,"");
	    						episodeList.push({"aText":aText, "href":href, "description":""});
							}
						});
					}
				}catch(e){}
				//加入油猴缓存
				episodeObj.websiteTitle="qq";
				episodeObj.originVideoUrl=website_host;
				if(episodeList.length!=0){
					episodeObj.episodeList=episodeList;
	    		}
				GM_setValue("episodeObj",episodeObj);
			},100);
		};
		if(website_host==="www.iqiyi.com"){
			var episodeObj = vipVideoAnalysis.paramsSelectedInit();
			var episodeList = episodeObj.episodeList;
			var $i71playpagesdramalist = $("div[is='i71-playpage-sdrama-list']");
			var aid = "";
			if(!!$i71playpagesdramalist){
				var data =  $i71playpagesdramalist.attr(":initialized-data");
				if(!!data){
					var dataJson = JSON.parse(data);
					try{
						for(var i=0; i<dataJson.length; i++){
							var aText = dataJson[i].order;
							var tvId = dataJson[i].tvId;
							aid = dataJson[i].albumId;
							var description = dataJson[i].subtitle;
							if(!!aText && !!tvId){
								var href = "https://pcw-api.iqiyi.com/video/video/playervideoinfo?tvid="+tvId+"&locale=cn_s";
								episodeList.push({"aText":aText, "href":href, "description":description});
							}
						}
					}catch(err){}
				}
			}
			//加入油猴缓存
			episodeObj.websiteTitle="iqiyi";
			episodeObj.originVideoUrl=website_host;
			if(episodeList.length!=0){
				episodeObj.episodeList=episodeList;
			}
			GM_setValue("episodeObj",episodeObj);
		};
		if(website_host==="www.mgtv.com"){
			var episodeObj = vipVideoAnalysis.paramsSelectedInit();
			var episodeList = episodeObj.episodeList;
			setTimeout(function(){
				$("body").find(".aside-tabbox").each(function(){
					$(this).find("li").each(function(){
	    				var $a = $(this).find("a");
						var href = $a.attr("href");
						var aText = $(this).text();
						if(!!href){
							href = "https://www.mgtv.com"+href;
							episodeList.push({"aText":aText, "href":href, "description":""});
						}
					});
				});
				//加入油猴缓存
				episodeObj.websiteTitle="mgtv";
				episodeObj.originVideoUrl=website_host;
				if(episodeList.length!=0){
					episodeObj.episodeList=episodeList;
	    		}
				GM_setValue("episodeObj",episodeObj);
			},1000);
		};
		if(website_host==="v.youku.com"){
			var episodeObj = vipVideoAnalysis.paramsSelectedInit();
			var episodeList = episodeObj.episodeList;
			$("#bpmodule-playpage-anthology").find("#listitem_page1").find(".item-num").each(function(){
				var title = $(this).attr("title");
				var $a = $(this).find("a");
				var href = $a.attr("href");
				if(!!href){
					href = "https:"+href;
					var aText = $a.text();
					aText = aText.replace(/\s/g,"");
					episodeList.push({"aText":aText, "href":href, "description":title});
				}
			});
			//加入油猴缓存
			episodeObj.websiteTitle="youku";
			episodeObj.originVideoUrl=website_host;
			if(episodeList.length!=0){
    			episodeObj.episodeList=episodeList;
    		}
			GM_setValue("episodeObj",episodeObj);
		};
		if(website_host==="tv.sohu.com"){
			var episodeObj = vipVideoAnalysis.paramsSelectedInit();
			var episodeList = episodeObj.episodeList;
			setTimeout(function(){
				var $jlistwrap = $(".j-list-wrap");
				if(!!$jlistwrap){
					$jlistwrap.find("li").each(function(){
						var $a = $(this).find("a");
						if(!!$a){
							var aText = $(this).attr("data-order");
							var href = $a.attr("href");
							var title = $a.attr("data-title");
							if(!!aText && !!href){
								href = "https"+href;
								episodeList.push({"aText":aText, "href":href, "description":title});
								console.log({"aText":aText, "href":href, "description":title});
							}
						}
					});
				}
				//加入油猴缓存
				episodeObj.websiteTitle="sohu";
				episodeObj.originVideoUrl=website_host;
				if(episodeList.length!=0){
	    			episodeObj.episodeList=episodeList;
	    		}
				GM_setValue("episodeObj",episodeObj);
			},1000);
		};
	};
	//支持电视剧选集
	vipVideoAnalysis.movieWebsitesPlayersSelected=function(){
		if(website_host=="v.sosoik.top" && window_url.indexOf("v.sosoik.top/v/s")){
			var innerCss= 
				`
				#plugin_doc_episode_box{position:fixed; top:170px; left:10px;}
				#plugin_doc_episode_box >a{display:inline-block;width:25px;height:25px;text-align:center;line-height:25px;background-color:#888;margin:5px;border-radius:3px;color:#FFF;text-decoration:none;cursor:pointer;}
				#plugin_doc_episode_box >a:hover{background-color:#000;}
				#plugin_doc_episode_box >.active{background-color:#000;}
				#plugin_doc_episode_box >.tip{text-align:center;padding:5px;}
				#plugin_doc_episode_box .origin-video-url{word-wrap:break-word;word-break:break-all;white-space:pre-wrap;}
				@media (max-width: 767px) {#plugin_doc_episode_box{display:none;}}
				`;
			$("body").prepend("<style>"+innerCss+"</style>");
			
			var episodeObj = GM_getValue("episodeObj");
			if(!!episodeObj){
				var episodeList = episodeObj.episodeList;
				if(!!episodeList && episodeList.length!=0){
					var websiteTitle = episodeObj.websiteTitle;
					var currentvideourl = GM_getValue("currentvideourl");
					var html = "<div id='plugin_doc_episode_box'>";
					html += "<div class='tip'><b>电视剧点击集数，可自由选集</b></div>";
					var waiturl="";
					var aclass="";
					for(var i=0; i<episodeList.length; i++){
						waiturl=episodeList[i].href;
						aclass="plugin-episode";
						if(window_url.indexOf(waiturl)!=-1 || (currentvideourl==waiturl && websiteTitle=="iqiyi")){
							aclass = aclass +" "+"active";
						}
						html+= "<a class='"+aclass+"' data-href='"+waiturl+"' title='"+episodeList[i].description+"'>"+episodeList[i].aText+"</a>";
						if((i+1)%6==0){
							html+= "<br>";
						}
					}
					var originVideoUrl=episodeObj.originVideoUrl;
					if(!!originVideoUrl){
						html += "<div class='origin-video-url'><b>来源视频链接：<a href='"+originVideoUrl+"'>点我返回</a><b></div>";
					}
					html += "</div>";
					$("body").append(html);
				}
			}
			$("body").on("click", ".plugin-episode", function(){
				var href=$(this).data("href");
				if(!!href){
					GM_setValue("currentvideourl",href);
					if(href.indexOf("iqiyi.com")!=-1){ //爱奇艺过来的需要再次请求播放地址
						GM_xmlhttpRequest({
							url: href,
						  	method: "GET",
						  	headers: {"Content-Type": "application/x-www-form-urlencoded"},
						  	onload: function(response) {
								var status = response.status;
								if(status==200||status=='200'){
									var serverResponseJson = JSON.parse(response.responseText);
									var code = serverResponseJson.code;
									if(code=="A00000"){
										try{
											var playurl = serverResponseJson.data.vu;
											if(!!playurl){
												playurl = "http://v.sosoik.top/v/s/?url="+playurl;
												window.location.href=playurl;
											}
										}catch(e){}
									}
								}
						  	}
						});
					}else{
						href = "http://v.sosoik.top/v/s/?url="+href;
						window.location.href=href;
					}
				}
			});
		}
	}
	vipVideoAnalysis.start=function(){
    	if(vipVideoAnalysis.judgeVipWebsite() && window.top == window.self){
    		vipVideoAnalysis.addStyle();
			vipVideoAnalysis.generateHtml();
			vipVideoAnalysis.operation();
    		vipVideoAnalysis.getSelected();
    	}
    	vipVideoAnalysis.movieWebsitesPlayersSelected();
    };
	vipVideoAnalysis.start();
	
   	//VIP解析执行到此
   	if(vipVideoAnalysis.judgeVipWebsite()){
   		return false;
   	}
   	//////VIP解析结束///////
   	
    /*
    * 网页解除限制，集成了脚本：网页限制解除（精简优化版）
    * 作者：Cat73、xinggsf
    * 插件版本：1.5.6
    * 原插件地址：https://greasyfork.org/zh-CN/scripts/41075
    */
	// 域名规则列表
	const rules = {
		plus: {
			name: "default",
			hook_eventNames: "contextmenu|select|selectstart|copy|cut|dragstart",
			unhook_eventNames: "mousedown|mouseup|keydown|keyup",
			dom0: true,
			hook_addEventListener: true,
			hook_preventDefault: true,
			add_css: true
		}
	};
	
	const returnTrue = e => true;
	// 获取目标域名应该使用的规则
	const getRule = (host) => {
		return rules.plus;
	};
	const dontHook = e => !!e.closest('form');
	// 储存被 Hook 的函数
	const EventTarget_addEventListener = EventTarget.prototype.addEventListener;
	const document_addEventListener = document.addEventListener;
	const Event_preventDefault = Event.prototype.preventDefault;
	// 要处理的 event 列表
	let hook_eventNames, unhook_eventNames, eventNames;
	
	// Hook addEventListener proc
	function addEventListener(type, func, useCapture) {
		let _addEventListener = this === document ? document_addEventListener : EventTarget_addEventListener;
		if (!hook_eventNames.includes(type)) {
			_addEventListener.apply(this, arguments);
		} else {
			_addEventListener.apply(this, [type, returnTrue, useCapture]);
		}
	}
	
	// 清理或还原DOM节点的onxxx属性
	function clearLoop() {
		let type, prop,
		c = [document,document.body, ...document.getElementsByTagName('div')],
		// https://life.tw/?app=view&no=746862
		e = document.querySelector('iframe[src="about:blank"]');
		if (e && e.clientWidth>99 && e.clientHeight>11){
			e = e.contentWindow.document;
			c.push(e, e.body);
		}
	
		for (e of c) {
			if (!e) continue;
			e = e.wrappedJSObject || e;
			for (type of eventNames) {
				prop = 'on' + type;
				e[prop] = null;
			}
		}
	}
	
	function init() {
		// 获取当前域名的规则
		let rule = getRule(location.host);
	
		// 设置 event 列表
		hook_eventNames = rule.hook_eventNames.split("|");
		// Allowed to return value
		unhook_eventNames = rule.unhook_eventNames.split("|");
		eventNames = hook_eventNames.concat(unhook_eventNames);
	
		if (rule.dom0) {
			setInterval(clearLoop, 9e3);
			setTimeout(clearLoop, 1e3);
			window.addEventListener('load', clearLoop, true);
		}
	
		if (rule.hook_addEventListener) {
			EventTarget.prototype.addEventListener = addEventListener;
			document.addEventListener = addEventListener;
		}
	
		if (rule.hook_preventDefault) {
			Event.prototype.preventDefault = function () {
				if (dontHook(this.target) || !eventNames.includes(this.type)) {
					Event_preventDefault.apply(this, arguments);
				}
			};
		}
	
		if (rule.add_css) GM_addStyle(
			`html, * {
				-webkit-user-select:text !important;
				-moz-user-select:text !important;
				user-select:text !important;
			}
			::-moz-selection {color:#FFF!important; background:#3390FF!important;}
			::selection {color:#FFF!important; background:#3390FF!important;}`
		);
	}
	init();
})();