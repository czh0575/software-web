// ==UserScript==
// @name        VIP视频免费看
// @namespace    https://www.luckyblank.cn/jiaoben/vipvideos
// @version      20.20.12.05
// @description  【移除知乎弹窗】【增加1905网站支持】【公众号搜索 无心VIP影视 】【手机无广告】全网最新题库，支持图片题，永久免费！AND 用网站一站式解析和多接口集成的方式直接调用接口，接口全部亲自测试过，同时接口支持长期的更新替换工作。在保证接口解析质量的前提下，不断地优化界面以及提高用户使用体验。因为只专注于vip影视解析，所以更专业更值得信赖。注：对接公众号【无心VIP影视】，已适配爱奇艺全部电影，手机上方便看VIP视频。操作请看更新说明。
// @author       我本无心
// @icon         http://www.luckyblank.cn/jiaoben/favorite.ico
// @match        *://v.youku.com/v_show/*
// @match        *://*.iqiyi.com/v_*
// @match        *://*.iqiyi.com/w_*
// @match        *://*.iqiyi.com/a_*
// @match        *://*.iqiyi.com/dianying/*
// @match        *://*.le.com/ptv/vplay/*
// @match        *://v.qq.com/x/cover/*
// @match        *://v.qq.com/x/page/*
// @match        *://*.tudou.com/listplay/*
// @match        *://*.tudou.com/albumplay/*
// @match        *://*.tudou.com/programs/view/*
// @match        *://*.mgtv.com/b/*
// @match        *://film.sohu.com/album/*
// @match        *://*.acfun.cn/v/*
// @match        *://*.bilibili.com/video/*
// @match        *://*.bilibili.com/anime/*
// @match        *://vip.pptv.com/show/*
// @match        *://v.pptv.com/show/*
// @match        *://v.yinyuetai.com/video/*
// @match        *://v.yinyuetai.com/playlist/*
// @match        *://*.wasu.cn/Play/show/*
// @match        *://vip.1905.com/play/*
// @match        *://www.zhihu.com/question/*
// @run-at       document-end
// @grant        GM_xmlhttpRequest
// @grant        GM_info
// @grant        GM_getValue
// @grant        GM_setValue
// @run-at       document-end
// @grant        unsafeWindow
// @grant        GM_addStyle
// @grant        GM_setClipboard
// @require      https://cdn.staticfile.org/jquery/1.12.4/jquery.min.js
// @require      https://cdn.bootcdn.net/ajax/libs/layer/3.1.1/layer.js
// @require      https://cdn.bootcss.com/babel-standalone/6.26.0/babel.min.js
// @require      https://cdn.bootcss.com/clipboard.js/1.5.16/clipboard.min.js
// @require      https://cdn.staticfile.org/jquery-cookie/1.4.1/jquery.cookie.min.js
// @license      MIT

// ==/UserScript==
(function () {
    'use strict';
    var curPlaySite = '';
    var curWords = '';
    var html = '';
    var name = '';
    var videoSite = window.location.href;
    var currentUrl = window.location.href;
    var reYk = /youku/i;
    var reAqy = /iqiyi/i;
    var reLS = /le/i;
    var reTX = /qq/i;
    var reTD = /tudou/i;
    var reMG = /mgtv/i;
    var reSH = /sohu/i;
    var reAF = /acfun/i;
    var reBL = /bilibili/i;
    var reYJ = /1905/i;
    var rePP = /pptv/i;
    var reYYT = /yinyuetai/i;
    var zhihu =/zhihu\.com\/question/i;

//FUN_1
//vip视频解析
    if (reAqy.test(videoSite) || reLS.test(videoSite) || reTX.test(videoSite) || reTD.test(videoSite) || reMG.test(videoSite) || reSH.test(videoSite) || reAF.test(videoSite) || reBL.test(videoSite) || rePP.test(videoSite) || reYk.test(videoSite)|| reYJ.test(videoSite) || reYYT.test(videoSite)) {
        console.log("FUN_1 HAS RUNNING....")
        //先添加样式
        $("head").append($('<link rel="stylesheet" href="//www.luckyblank.cn/jiaoben/css/videoparse.css">'));
       $("head").append($('<link rel="stylesheet" href="https://www.luckyblank.cn/tools/layer/layer-v3.1.1/layer/theme/default/layer.css">'));
        var arr = getAll();
        window.q = function (cssSelector) {
            return document.querySelector(cssSelector);
        };
        var intervalId = null;
        var ischeck = false;
        var queryyhq = "";
        // 影视地址检测
        //if(WYYY_RE.test(videoSite)||QQYY_RE.test(videoSite)||KGYY_RE.test(videoSite)||KWYY_RE.test(videoSite)||XMYY_RE.test(videoSite)||BDYY_RE.test(videoSite)||QTYY_RE.test(videoSite)||LZYY_RE.test(videoSite)||MGYY_RE.test(videoSite)||XMLYYY_RE.test(videoSite)||YK_RE.test(videoSite)||AQY_RE.test(videoSite)||LS_RE.test(videoSite)||TX_RE.test(videoSite)||TD_RE.test(videoSite)||MG_RE.test(videoSite)||SH_RE.test(videoSite)||AF_RE.test(videoSite)||BL_RE.test(videoSite)||YJ_RE.test(videoSite)||PP_RE.test(videoSite)||YYT_RE.test(videoSite)){
        var sidenav = '<div class="aside-nav bounceInUp animated" id="aside-nav">' +
            '<label for="" class="aside-menu" title="\u62d6\u52a8\u9f20\u6807\u79fb\u52a8">VIP</label>' +
            '<a href="javascript:void(0)" title="\u70b9\u6b64\u8fdb\u884c\u7f51\u7ad9\u89e3\u6790"' +
            ' data-cat="search" class="menu-item menu-line menu-first">\u7f51\u7ad9<br>\u89e3\u6790</a>' +
            '<a href="javascript:void(0)"' +
            'title="\u8fd9\u662f\u4e3b\u63a5\u53e3\uff0c\u4e13\u95e8\u7528\u4e8e\u89e3\u6790\u0076\u0069\u0070\u89c6\u9891\uff01" ' +
            'data-cat="process" class="menu-item menu-line menu-second">\u89e3\u6790<br>\u63a5\u53e3</a>' +
            '<a href="javascript:void(0)"' +
            ' title="\u8fd9\u662f\u5907\u7528\u63a5\u53e3\uff0c\u4e13\u95e8\u7528\u4e8e\u89e3\u6790\u0076\u0069\u0070\u89c6\u9891\uff01" ' +
            'data-cat="tb" class="menu-item menu-line menu-third">\u5907\u7528<br>\u63a5\u53e3</a>' +
            '<a href="javascript:void(0)" ' +
            'title="\u0051\u0051\u7fa4\uff1a\u0039\u0034\u0031\u0039\u0030\u0035\u0034\u0033\u0034\u0020\u6b22\u8fce\u52a0\u5165\uff01"' +
            ' data-cat="music" class="menu-item menu-line menu-fourth">\u8fdb\u7fa4<br>\u53cd\u9988</a>' +
            '<a href="javascript:void(0)" ' +
            'title="\u8fd9\u662f\u63d2\u4ef6\u533a\uff0c\u5728\u8fd9\u91cc\u4f60\u53ef\u4ee5\u627e\u5230\u5404\u79cd\u597d\u73a9\u7684\u6d4f\u89c8\u5668\u63d2\u4ef6\uff01" ' +
            'data-cat="jingxuan" class="menu-item menu-line menu-fifth">\u63d2\u4ef6<br>\u4e0b\u8f7d</a>' +
            '<a href="javascript:void(0)" ' +
            ' title="\u8fd9\u662f\u63a5\u53e3\u5927\u5168\uff0c\u6709\u4e30\u5bcc\u7684\u63a5\u53e3\u8ba9\u4f60\u66ff\u6362\uff01"' +
            ' data-cat="help" class="menu-item menu-line menu-sixth">\u63a5\u53e3<br>\u5927\u5168</a></div>';
        sidenav += '<section class="ch1 doudong"> <a href="javascript:void(0)" data-cat="tmall1111" target="_blank" title="free"></a></section>';
        $("body").append(sidenav);
        var ua = navigator.userAgent;
        /Safari|iPhone/i.test(ua) && 0 == /chrome/i.test(ua) && $("#aside-nav").addClass("no-filter");
        var drags = {
                down: !1,
                x: 0,
                y: 0,
                winWid: 0,
                winHei: 0,
                clientX: 0,
                clientY: 0
            },
            asideNav = $("#aside-nav")[0],
            getCss = function (a, e) {
                return a.currentStyle ? a.currentStyle[e] : document.defaultView.getComputedStyle(a, !1)[e]
            };
        $("#aside-nav").on("mousedown", function (a) {
            drags.down = !0, drags.clientX = a.clientX, drags.clientY = a.clientY, drags.x = getCss(this, "right"), drags.y = getCss(this, "top"), drags.winHei = $(window).height(), drags.winWid = $(window).width(), $(document).on("mousemove", function (a) {
                if (drags.winWid > 640 && (a.clientX < 120 || a.clientX > drags.winWid - 50))
                    return !1;
                if (a.clientY < 180 || a.clientY > drags.winHei - 120)
                    return !1;
                var e = a.clientX - drags.clientX,
                    t = a.clientY - drags.clientY;
                asideNav.style.top = parseInt(drags.y) + t + "px";
                asideNav.style.right = parseInt(drags.x) - e + "px";
            })
        }).on("mouseup", function () {
            drags.down = !1, $(document).off("mousemove")
        });
        //jx1
        $('body').on('click', '[data-cat=process]', function () {
            window.open(arr[0] + videoSite);
        });
        //wangzhan
        $('body').on('click', '[data-cat=search]', function () {
            window.open('https://www.luckyblank.cn/jiaoben/vipvideos/index.html?link=' + videoSite);
        });
        //jx2
        $('body').on('click', '[data-cat=tb]', function () {
            window.open(arr[1] + videoSite);
        });
        //jiaqun
        $('body').on('click', '[data-cat=music]', function () {
            window.open('//shang.qq.com/wpa/qunwpa?idkey=959be373da1fb42096c6391a8f182dad15a7d567f136a99afa991a0975c677be');
        });
        //jx4
        $('body').on('click', '[data-cat=jingxuan]', function () {
            window.open('https://lanzous.com/b0e6zvlc');
        });
        //jx3
        $('body').on('click', '[data-cat=help]', function () {
            window.open('//www.luckyblank.cn/video/backstage/list.php');
        });
        //free
        $('body').on('click', '[data-cat=tmall1111]', function () {

            window.open('http://www.luckyblank.cn');
        });
        function timerDoOnce(node, functionName, checkTime) {
            var tt = setInterval(function () {
                if (document.querySelector(node) != null) {
                    clearInterval(tt);
                    functionName();
                }
            }, checkTime);
        }
        //获取所有接口
        function getAll() {
            var vips;
            $.ajax({
                url: '//www.luckyblank.cn:8443/vipaddress/getaddress',
                type: "GET",
                async: false,
                success: function (data) {
                    vips = data;
                }
            });
          //  console.log("vips:" + vips)
            return vips;
        }
        function addStyle(css) {
            var pi = document.createProcessingInstruction(
                'xml-stylesheet',
                'type="text/css" href="data:text/css;utf-8,' + encodeURIComponent(css) + '"'
            );
            return document.insertBefore(pi, document.documentElement);
        }
        function GetUrlParam(paraName) {
            var url = window.location.href;
            var arrObj = url.split("?");
            if (arrObj.length > 1) {
                var arrPara = arrObj[1].split("&");
                var arr;
                for (var i = 0; i < arrPara.length; i++) {
                    arr = arrPara[i].split("=");

                    if (arr != null && arr[0] == paraName) {
                        return arr[1];
                    }
                }
                return "";
            } else {
                return "";
            }
        }
            sentNotic(true);
//是否发送公告yes = true则执行
  function sentNotic(yes) {
      if(yes){
      //判断用户是否是第一次使用
       if($.cookie('isFirst') == undefined ){
       console.log("first......");
  var method_own ={
		notice: function(){
      //示范一个公告层
		  layer.open({
			type: 1
			,title: false //不显示标题栏
			,closeBtn: false
			,area: '350px;'
			,shade: 0.8
			,id: 'LAY_layuipro' //设定一个id，防止重复弹出
			,btn: ['火速围观', '残忍拒绝']
			,btnAlign: 'c'
			,moveType: 1 //拖拽模式，0或者1
			,content: '<div class="notice-wechat" style="padding: 50px; line-height: 22px; background-color: #393D49; color: #fff; font-weight: 300;"><img class="qrcode-wechat" src="https://www.luckyblank.cn/img/wechat/gzh.jpg"><br><br>你知道吗？亲！无心影视出公众号啦~<br></div>'
			,success: function(layero){
				//修正弹出层位置
				layero.css({"top":""})
			  var btn = layero.find('.layui-layer-btn');
			  btn.find('.layui-layer-btn0').attr({
				href: 'https://mp.weixin.qq.com/s/qPGdcfvT4_UHAS_JzU7Exg'
				,target: '_blank'
			  });
			}
		  });
    }
}
  method_own.notice();
  $.cookie('isFirst', '1', { expires: 1, path: '/' });
       } else{
           console.log('not the first....')
           //设置cookie为1天
           //var flag =    $.removeCookie('isFirst', { path: '/' }); // => true
           //console.log(flag)
       }
      }
  }
//直接退出
 return false;
    }

//FUN_3 知乎去除弹窗
    if (zhihu.test(currentUrl)){
          console.log("FUN_3 HAS RUNNING....")
        var style_wrapper = $("<style></style>");
    style_wrapper.append("html{overflow:auto !important } .Modal-wrapper{ display:none!important;}")
     $("head").append(style_wrapper);
     //直接退出
 return false;
        }
//TO-DO....
    //FUN_2
//超星网课助手


})();