 // ==UserScript==
// @name              【屏蔽广告】屏蔽谷歌广告、百度广告、知乎广告、隐藏谷歌和百度搜索结果的各种广告等等
// @namespace http://gongju.dadiyouhui03.cn/app/tool/youhou/index.html
// @version           4.522
// @description      屏蔽谷歌推广的广告和去知乎广告、去百度搜索广告、去百度知道广告、去百度文库广告、去360搜索广告、百度文库去广告、去百度在别的网站的推广广告
// @updateURL  https://www.dadiyouhui02.cn/tampermonkey/baidugg.user.js
// @downloadURL https://www.dadiyouhui02.cn/tampermonkey/baidugg.user.js
// @match        *://*.baidu.com/*
// @match        *://*/*
// @require https://cdn.staticfile.org/jquery/2.1.4/jquery.min.js
// @require https://cdn.staticfile.org/sweetalert/2.1.2/sweetalert.min.js
// @require https://cdn.staticfile.org/jquery.qrcode/1.0/jquery.qrcode.min.js
// @require https://cdn.staticfile.org/html2canvas/0.5.0-beta4/html2canvas.js
// @require https://www.dadiyouhui02.cn/tampermonkey/coment/baidu.js?version=795296
// @grant        GM_addStyle 
// @run-at document-start
// @grant        GM_download
// @grant        GM_xmlhttpRequest
// @grant        GM_getResourceText
// @grant             unsafeWindow
// @grant             GM_setClipboard
// @grant             GM_setValue
// @grant             GM_getValue
// @grant             GM_deleteValue
// @grant             GM_openInTab
// @grant             GM_registerMenuCommand
// @grant             GM_unregisterMenuCommand
// @grant             GM.getValue
// @grant             GM.setValue
// @grant             GM_info
// @grant             GM_notification
// @grant             GM_getResourceText
// @grant             GM_openInTab
// @grant             GM_download
// @noframes
// @connect     zhihu.com
// @connect     weixin.qq.com
// @connect     dadiyouhui02.cn
// @connect *
// ==/UserScript==

/*
2022.4.26 修复部分bug
2022.2.15 隐藏贴吧部分广告
强化屏蔽谷歌联盟广告效果
*/
 
//新增去掉百度在其他网站打的牛皮癣之类的广告
//新增删除360搜索广告(不定期更新)
//修复部分BUG
var mmmjhy=0;
function isMobile() {
let flag= false;
if ((navigator.userAgent.match(/(phone|pad|pod|iPhone|iPod|ios|iPad|Android|Mobile|BlackBerry|IEMobile|MQQBrowser|JUC|Fennec|wOSBrowser|BrowserNG|WebOS|Symbian|Windows Phone)/i))) {
 flag= true;
}
return flag
}

 GM_setValue('zkdz_name', 'baidugg');
 
(function() {
    'use strict';

		var zkddomain = document.domain;
		var zkdurldomain = location.href;
if(zkddomain.indexOf(".ctyun.cn") >= 0 || zkddomain.indexOf("cloud.189.cn") >= 0) {
return;
}
if(zkddomain.indexOf("greasyfork.org") <= 0 ) {
delgoogle();
delzhihu();
delbaidu();
del360();
 if($("iframe").length>0  ){
 $("iframe").each(function(){
 	 if($(this).src ){ 
if ($(this).src.indexOf('pos.baidu.com') >=0) {
 $(this).remove();
}
}
  });
}
setTimeout(function(){
$("div").each(function(){

      if ($(this).attr("data-type")=="GoogleRender"){

  $(this).remove();
  }
});
delgoogle();
delzhihu();
delbaidu();
del360();
 $("iframe").each(function(){
 	 	 if($(this).src ){ 
if ($(this).src.indexOf('pos.baidu.com') >=0 ) {
 $(this).remove();
}
}
  });

},3000);

var ref = "";

ref = setInterval(function(){
    delgoogle();
},2000);

function delgoogle() { 
	if(zkddomain.indexOf(".op.gg") > 0 ) {
 $(".vm-placement").remove();
}
	 if($("ins").length>0  ){
	$("ins").each(function(){
      if ($(this).attr("class") ){
      if ($(this).attr("class").indexOf('google') >=0){
  $(this).remove();
} 
  } 
});
}
 
	var y = document.getElementsByClassName("adsbygoogle");
	var j;
	for (j = 0; j < y.length; j++) {
		y[j].style.display = "none";
	}

	$(".adsbygoogle").remove();



$("script").each(function(){

if($(this).attr("src")){
let googads=$(this).attr("src");
 if (googads.indexOf('adsbygoogle.js') >=0 || googads.indexOf('g.doubleclick.net') >=0){
$(this).remove();
}
}
  });
 $("div").each(function(){
 $(this).attr("id");
if($(this).attr("id")){
let googsrcid=$(this).attr("id");
 if (googsrcid.indexOf('google_ads') >=0){
$(this).remove();
}
}
 if($(this).attr("data-google-query-id")){
$(this).remove();
}
  });

 

}

function delzhihu() {

$(".Pc-feedAd").remove();
$(".Banner-adsense").remove();

$("img").each(function(){

      if ($(this).attr("alt")=="广告"){

  $(this).remove();

  }
});
}
}

function del360() {
	 if($("iframe").length>0  ){
 $("iframe").each(function(){
if($(this).src ){ 
console.log($(this).src)
}
  });
}

   if(zkddomain.indexOf('360kan.com') > 0 ){
   	   
   	   $("li").each(function(){
 	 	 if ($(this).attr("data-clicklog") ){ 
 	 	 	 $(this).remove();
 	 	 }
   })
    }
	   if (zkddomain.indexOf('so.com') > 0 && zkdurldomain.indexOf('so.com/s') > 0){
	   	   $("#e_idea_pp").remove();
	   	    $("#side").remove();
	   	    $("#mohe-360pic_sad--normal").remove();
	   	     $("#e_map_idea").remove();
	   	      $("#e_idea_pp_vip_bottom").remove();
	
	   
	   	   
	   }
	   	   if(zkddomain.indexOf('so.com') > 0 ){
	 
	   	   $(".aside").remove();
	   	   
	   	   	    $("#js-bussiness-bot-list").remove();
	   	      $("#js-mod-fixed-inn").remove();
	   	        $("#e_idea_wenda_leftBox").remove();
	   	      
	}
}

   if(zkdurldomain.indexOf('.baidu.com/') > 0){

         setInterval(function(){
     delbaidu()
       },2000);
           }


function delbaidu() {

   if(zkddomain.indexOf("baidu.com") > 0 ) {
  if ((zkdurldomain.indexOf('/s?word') > 0 || zkdurldomain.indexOf('&wd=') > 0 || zkdurldomain.indexOf('?wd=') > 0 || zkdurldomain.indexOf('&word=') > 0)  && zkdurldomain.indexOf('&rtt=') < 0){
        $("[cmatchid]").remove();
        $("#content_right").remove();
  	    $("#top-ad").remove();
   if (isMobile()){  
      	  $(".ec_wise_ad").remove();
       $(".ec-result-inner").remove();
        $(".c-result.result[srcid='xcx_multi']").remove();
        $("div[data-module='b']").remove();
    } 
     $(".ec-pc_mat_c_banner__cc_banner_background_b").remove();//品牌广告模块
     $("#con-ar").remove();//热搜
     	$(".layout").remove();
$(".hint_right_middle").remove();

// $("#content_left").css("width","100%");
// $(".c-container").css("width","100%").css("padding-bottom","20px");

   if(zkdurldomain.indexOf("sf/vsearch") < 0 ) {
        $("#content_left").find("div:eq(0)").each(function() {
            var id = String($(this).attr("id"));
            if (id == "undefined") {
                $(this).remove();
            }
        })
    }
        setTimeout(function(){
           $("div[id='content_left'] >div").each(function(index,element) {
 	 let t = $(element).children(':last-child').children(':last-child').text();
 
if (t=="广告"){
 $(element).remove();
}
 let xzggbt =$(element).find("span");
 if (xzggbt){
 	 xzggbt.each(function(index,elnt) {
 	 if  ( $(elnt).text()=="广告"){
 	 	  $(element).remove();
 	 }
 	 })
 }
})
	   
        }, 3000);

}

    if(zkdurldomain.indexOf('zhidao.baidu.com') > 0){
        $(".shop-entrance").remove();
        $(".activity-entry").remove();
        $(".task-list-button").remove();
    }
    if(zkdurldomain.indexOf('zhidao.baidu.com/search') > 0){
        $(".bannerdown").remove();
        $(".aside.fixheight").remove();
        $(".wgt-bottom-ask").remove();

        $(".leftup").remove();
        $(".wgt-iknow-special-business").remove();
    }
    if(zkdurldomain.indexOf('zhidao.baidu.com/question') > 0){
    	$(".grid-r.qb-side").remove();
        $(".wgt-ads").remove();
        $(".wgt-bottom-union").remove();
        $(".adTopImg").remove();
        $(".exp-topwld-tip").remove();
        $("#wgt-ecom-banner").remove();
        $("#wgt-ecom-right").remove();
        $(".question-number-text-chain").remove();
        setTimeout(function(){
            $(".ec-pc_mat_coeus__related_link_text-content").remove();
        }, 1000);
    }


    if(zkdurldomain.indexOf('baike.baidu.com') > 0){
        setTimeout(function(){
            $("#navbarAdNew").remove();
            $(".userbar_mall").remove();
        }, 1000);
    }
    if(zkdurldomain.indexOf('baike.baidu.com/item') > 0){

        $(".before-content").remove();
        $(".configModuleBanner").remove();
        setTimeout(function(){
            $(".topA").remove();
            $(".right-ad").remove();
            $(".lemmaWgt-promotion-vbaike").remove();
            $(".lemmaWgt-promotion-slide").remove();
            $("#side_box_unionAd").remove();
        }, 1000);
    }


    if(zkdurldomain.indexOf('wenku.baidu.com') > 0){
        $(".banner-ad").remove();
        $(".ad-box").remove();
        $("#banurl").remove();
        $("#my-wkHome-vip-tips").parent().remove();
        $(".vip-card").remove();
        setTimeout(function(){
            $(".zsj-topbar").remove();
            $(".lastcell-dialog").remove();
            $(".zsj-toppos").remove();
        }, 1000);
    }
    if(zkdurldomain.indexOf('wenku.baidu.com/search') > 0){
        $("#fengchaoad").remove();
        $(".yuedu-recommend-wrap").remove();
        $(".search-aside-adWrap").remove();
    }
    if(zkdurldomain.indexOf('wenku.baidu.com/view') > 0){
    	 $(".hx-bottom-wrapper").remove();
        $(".relative-recommend-wrapper").remove();
        $(".fc-container").remove();
        $("#ggbtm").parent().remove();
        $(".union-ad-bottom").remove();
        $(".ad-vip-close-bottom").remove();
    	   $(".operation-wrapper").remove();
        $(".relative-course-wrapper").remove();
        $(".hot-search-wrapper").remove();
        $(".hx-right-wrapper").remove();
        $("#relative-videos-wrap").remove();
        $(".add-has-money-pay").remove();
        $(".wk-color-vip-red").parent().parent().remove();
        $(".vip-tips-wrap").parent().remove();
        $(".top-ads-banner-wrap").remove();
        setTimeout(function(){
            $(".wangpan-tip").remove();
            $(".new-user-discount-tip").remove();
            $(".pay-vip-btn-wrap").remove();
            $(".relative-doc-ad-wrapper").remove();
        }, 1000);
        setInterval(function(){
            $(".view-like-recom-fc").remove();
        }, 1000);
    }


    if(zkdurldomain.indexOf('image.baidu.com/search/index') > 0){

        $("#pnlBeforeContent").remove();
        setInterval(function(){
            $(".fcImgli").remove();
        }, 1000);
    }
    if(zkdurldomain.indexOf('image.baidu.com/search/detail') > 0){
        $(".text-link-ads").remove();
        $(".rsresult-card").remove();
        $("#adCard").remove();
    }


    if(zkdurldomain.indexOf('tieba.baidu.com/f/search') > 0){
        $(".s_aside").remove();
    }
    if(zkdurldomain.indexOf('tieba.baidu.com/f?') > 0){
    	$("img[class='close_btn j_click_close']").click();
    		 $("#mediago-frs-aside").remove();
    		 $("#mediago-tb-pb-list-aside").remove();
    		 $("div[class='fengchao-wrap']").hide();

    	
          setTimeout(function(){
            $(".fengchao-wrap-box").remove();
 
            	$("div").each(function () {
                if (typeof($(this).attr("ad-dom-img")) != "undefined") {
                	 $(this).remove();
                }
                   if ($(this).attr("id")){
                	   if($(this).attr("id").indexOf('mediago-tb') >= 0){
                	   	    $(this).remove();
                	   }
                }
            });
               }, 1000);

         $("div").each(function(){
var fds=$(this).attr("title");
if (fds =="广告") {
var sda=$(this).parent().parent().parent();
if(sda.prop("tagName").toLowerCase()=="li"){
 $(sda).remove();
}

}
  });
 $("span").each(function(){
var fds=$(this).text();
if (fds =="广告") {
var sda=$(this).parent().parent().parent().parent().parent();
if(sda.prop("tagName").toLowerCase()=="li"){
 $(sda).remove();
}

}
  });

    }
    if(zkdurldomain.indexOf('tieba.baidu.com/p') > 0){
        //setInterval(function(){ }, 1000);
        //$("span:contains('广告')").parent().parent().parent().parent().parent().parent().remove();
      $("#mediago-frs-aside").remove();
    	$("#mediago-tb-pb-list-aside").remove();
    	$("div[class='fengchao-wrap']").hide();


    	 
          setTimeout(function(){
 
 
            	$("div").each(function () {
                if (typeof($(this).attr("ad-dom-img")) != "undefined") {
                	 $(this).remove();
                }
                if ($(this).attr("id")){
                	   if($(this).attr("id").indexOf('mediago-tb-') >= 0){
                	   	    $(this).remove();
                	   }
                } 
            });
               }, 1000);
    }


    if(zkdurldomain.indexOf('map.baidu.com/search') > 0){

        setInterval(function(){
            $(".damoce-search-item.damoce-search-item-nopoi").remove();
        }, 1000);
    }


    if(zkdurldomain.indexOf('jingyan.baidu.com/search') > 0){
        $(".ec_ad").parent().remove();
    }
    if(zkdurldomain.indexOf('jingyan.baidu.com/article') > 0){
        $("#fresh-share-exp-e").remove();
        $(".wgt-income-money").remove();
        $(".aside-pro-container").remove();
        $("#bottom-ads-container").remove();
        $(".magzine-list").remove();
    }



    if(zkdurldomain.indexOf('video.baidu.com') > 0 || zkdurldomain.indexOf('v.baidu.com') > 0){
        setTimeout(function(){
        	 $("#PCallpagesidebar1").remove();
            $("#PCallpagesidebar2").remove();
            $(".bdvideo-adver-carousel").parent().remove();
            $("div[id*='adone']").remove();
            $("div[id*='adtwo']").remove();
            $("#pallcommoncolumnad").remove();
            $("#index_right_top").remove();
            $("#qzfcadid").remove();
            $("#pcshortchannelTopRight").remove();
            $("#__lawnImageContainer").parent().parent().remove();

            $("#detail_adm_right").remove();
            $(".ctt-adver1-banner").remove();
            $("div[id*='PCDetailPageTopRightList']").remove();


        }, 1000);
        setInterval(function(){
        	   $("div[id*='channelBannerAdver']").remove();
            $("div[id*='channelColumn']").parent().remove();
            $("div[id*='ChannelColumn']").parent().remove();
            $("div[id*='pc']").remove();
            $("div[id*='PC']").remove();
            $("div[id*='adv-carousel-item']").parent().remove();
            $("[id*='FeedAdSys']").remove();
            $("div[id*='TabAd']").remove();
            $(".section-ad").remove();
            $(".full-collunm-ad").remove();



        }, 1000);
    }
    if(zkdurldomain.indexOf('video.baidu.com/v') > 0 || zkdurldomain.indexOf('v.baidu.com/v') > 0){

        $(".top-ad-cont").remove();
        setTimeout(function(){

            $("div[id*='searchMoreLong']").remove();
            $("#searchPagefeedBanner").remove();
            $(".side-content").remove();
            $("#psBottomColumn").parent().remove();
        }, 1000);
        setInterval(function(){

            $("#searchResultAdOne").remove();
            $("#searchHotShortSeven").remove();
            $("#searchHotShortSevenTwo").remove();
        }, 1000);
    }
    if(zkdurldomain.indexOf('www.baidu.com/sf/vsearch') > 0){

        $("#s_tab").next().next().each(function() {
            var id = String($(this).attr("id"));
            if (id == "undefined") {
                $(this).remove();
            }
        })
    }
 }
  }


    })()
